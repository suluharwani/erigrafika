#
# TABLE STRUCTURE FOR: about_us
#

DROP TABLE IF EXISTS `about_us`;

CREATE TABLE `about_us` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isi` varchar(5000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `about_us` (`id`, `isi`) VALUES (1, 'Pusat digitalprinting purwodadi BANNER SPANDUK STICKER BROSUR ALBATROS PEMBUATAN BANNER LANGSUNG JADI DI PURWODADI.');


#
# TABLE STRUCTURE FOR: admin
#

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(500) NOT NULL DEFAULT '0',
  `username` varchar(500) NOT NULL DEFAULT '0',
  `foto` varchar(500) NOT NULL DEFAULT '0',
  `password` varchar(500) NOT NULL DEFAULT '0',
  `level` varchar(500) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `admin` (`id`, `nama`, `username`, `foto`, `password`, `level`) VALUES (3, 'Erigrafika', 'suluh', '0', '$2a$08$vxCQf2lNEpcUOOcPXUip4OOKHClKqyLuy9iCZXnHv5hBajjH/63Dy', '1');


#
# TABLE STRUCTURE FOR: contact
#

DROP TABLE IF EXISTS `contact`;

CREATE TABLE `contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `telepon` varchar(500) NOT NULL,
  `email` varchar(500) NOT NULL,
  `alamat` varchar(500) NOT NULL,
  `buka` varchar(500) NOT NULL,
  `tutup` varchar(500) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `contact` (`id`, `telepon`, `email`, `alamat`, `buka`, `tutup`, `status`) VALUES (1, '082137300307', 'erigrafikaoke@gmail.com', 'Jl. Gajah Mada, porong, Kuripan, Kec. Purwodadi, Kabupaten Grobogan, Jawa Tengah 58113', 'Senin - Sabtu 08:30 - 16.30', 'Minggu', 1);


#
# TABLE STRUCTURE FOR: contact_admin
#

DROP TABLE IF EXISTS `contact_admin`;

CREATE TABLE `contact_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nomor_telepon` varchar(25) NOT NULL,
  `email` varchar(255) NOT NULL,
  `id_admin` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: contact_us
#

DROP TABLE IF EXISTS `contact_us`;

CREATE TABLE `contact_us` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_contact` int(11) NOT NULL DEFAULT '0',
  `alamat` varchar(500) DEFAULT NULL,
  `email` varchar(500) DEFAULT NULL,
  `telepon` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: data_admin
#

DROP TABLE IF EXISTS `data_admin`;

CREATE TABLE `data_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `alamat` varchar(255) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `id_admin` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: email_pengunjung
#

DROP TABLE IF EXISTS `email_pengunjung`;

CREATE TABLE `email_pengunjung` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `email` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: font_awesome_icon
#

DROP TABLE IF EXISTS `font_awesome_icon`;

CREATE TABLE `font_awesome_icon` (
  `icon` varchar(35) NOT NULL,
  `unicode` varchar(4) NOT NULL,
  `html` varchar(58) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('address-book', 'f2b9', '<i class=\'fa far-address-book\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('address-card', 'f2bb', '<i class=\'fa fas-address-card\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('adjust', 'f042', '<i class=\'fa fas-adjust\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('align-center', 'f037', '<i class=\'fa fas-align-center\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('align-justify', 'f039', '<i class=\'fa fas-align-justify\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('align-left', 'f036', '<i class=\'fa fas-align-left\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('align-right', 'f038', '<i class=\'fa fas-align-right\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('allergies', 'f461', '<i class=\'fa fas-allergies\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('ambulance', 'f0f9', '<i class=\'fa fas-ambulance\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('american-sign-language-interpreting', 'f2a3', '<i class=\'fa fas-american-sign-language-interpreting\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('anchor', 'f13d', '<i class=\'fa fas-anchor\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('angle-double-down', 'f103', '<i class=\'fa fas-angle-double-down\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('angle-double-left', 'f100', '<i class=\'fa fas-angle-double-left\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('angle-double-right', 'f101', '<i class=\'fa fas-angle-double-right\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('angle-double-up', 'f102', '<i class=\'fa fas-angle-double-up\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('angle-down', 'f107', '<i class=\'fa fas-angle-down\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('angle-left', 'f104', '<i class=\'fa fas-angle-left\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('angle-right', 'f105', '<i class=\'fa fas-angle-right\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('angle-up', 'f106', '<i class=\'fa fas-angle-up\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('archive', 'f187', '<i class=\'fa fas-archive\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('arrow-alt-circle-down', 'f358', '<i class=\'fa fas-arrow-alt-circle-down\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('arrow-alt-circle-left', 'f359', '<i class=\'fa fas-arrow-alt-circle-left\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('arrow-alt-circle-right', 'f35a', '<i class=\'fa fas-arrow-alt-circle-right\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('arrow-alt-circle-up', 'f35b', '<i class=\'fa fas-arrow-alt-circle-up\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('arrow-circle-down', 'f0ab', '<i class=\'fa fas-arrow-circle-down\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('arrow-circle-left', 'f0a8', '<i class=\'fa fas-arrow-circle-left\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('arrow-circle-right', 'f0a9', '<i class=\'fa fas-arrow-circle-right\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('arrow-circle-up', 'f0aa', '<i class=\'fa fas-arrow-circle-up\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('arrow-down', 'f063', '<i class=\'fa fas-arrow-down\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('arrow-left', 'f060', '<i class=\'fa fas-arrow-left\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('arrow-right', 'f061', '<i class=\'fa fas-arrow-right\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('arrow-up', 'f062', '<i class=\'fa fas-arrow-up\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('arrows-alt', 'f0b2', '<i class=\'fa fas-arrows-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('arrows-alt-h', 'f337', '<i class=\'fa fas-arrows-alt-h\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('arrows-alt-v', 'f338', '<i class=\'fa fas-arrows-alt-v\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('assistive-listening-systems', 'f2a2', '<i class=\'fa fas-assistive-listening-systems\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('asterisk', 'f069', '<i class=\'fa fas-asterisk\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('at', 'f1fa', '<i class=\'fa fas-at\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('audio-description', 'f29e', '<i class=\'fa fas-audio-description\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('backward', 'f04a', '<i class=\'fa fas-backward\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('balance-scale', 'f24e', '<i class=\'fa fas-balance-scale\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('ban', 'f05e', '<i class=\'fa fas-ban\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('band-aid', 'f462', '<i class=\'fa fas-band-aid\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('barcode', 'f02a', '<i class=\'fa fas-barcode\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('bars', 'f0c9', '<i class=\'fa fas-bars\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('baseball-ball', 'f433', '<i class=\'fa fas-baseball-ball\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('basketball-ball', 'f434', '<i class=\'fa fas-basketball-ball\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('bath', 'f2cd', '<i class=\'fa fas-bath\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('battery-empty', 'f244', '<i class=\'fa fas-battery-empty\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('battery-full', 'f240', '<i class=\'fa fas-battery-full\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('battery-half', 'f242', '<i class=\'fa fas-battery-half\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('battery-quarter', 'f243', '<i class=\'fa fas-battery-quarter\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('battery-three-quarters', 'f241', '<i class=\'fa fas-battery-three-quarters\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('bed', 'f236', '<i class=\'fa fas-bed\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('beer', 'f0fc', '<i class=\'fa fas-beer\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('bell', 'f0f3', '<i class=\'fa fas-bell\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('bell-slash', 'f1f6', '<i class=\'fa fas-bell-slash\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('bicycle', 'f206', '<i class=\'fa fas-bicycle\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('binoculars', 'f1e5', '<i class=\'fa fas-binoculars\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('birthday-cake', 'f1fd', '<i class=\'fa fas-birthday-cake\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('blender', 'f517', '<i class=\'fa fas-blender\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('blind', 'f29d', '<i class=\'fa fas-blind\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('bold', 'f032', '<i class=\'fa fas-bold\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('bolt', 'f0e7', '<i class=\'fa fas-bolt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('bomb', 'f1e2', '<i class=\'fa fas-bomb\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('book', 'f02d', '<i class=\'fa fas-book\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('book-open', 'f518', '<i class=\'fa fas-book-open\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('bookmark', 'f02e', '<i class=\'fa fas-bookmark\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('bowling-ball', 'f436', '<i class=\'fa fas-bowling-ball\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('box', 'f466', '<i class=\'fa fas-box\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('box-open', 'f49e', '<i class=\'fa fas-box-open\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('boxes', 'f468', '<i class=\'fa fas-boxes\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('braille', 'f2a1', '<i class=\'fa fas-braille\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('briefcase', 'f0b1', '<i class=\'fa fas-briefcase\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('briefcase-medical', 'f469', '<i class=\'fa fas-briefcase-medical\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('broadcast-tower', 'f519', '<i class=\'fa fas-broadcast-tower\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('broom', 'f51a', '<i class=\'fa fas-broom\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('bug', 'f188', '<i class=\'fa fas-bug\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('building', 'f1ad', '<i class=\'fa fas-building\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('bullhorn', 'f0a1', '<i class=\'fa fas-bullhorn\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('bullseye', 'f140', '<i class=\'fa fas-bullseye\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('burn', 'f46a', '<i class=\'fa fas-burn\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('bus', 'f207', '<i class=\'fa fas-bus\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('calculator', 'f1ec', '<i class=\'fa fas-calculator\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('calendar', 'f133', '<i class=\'fa fas-calendar\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('calendar-alt', 'f073', '<i class=\'fa fas-calendar-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('calendar-check', 'f274', '<i class=\'fa fas-calendar-check\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('calendar-minus', 'f272', '<i class=\'fa fas-calendar-minus\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('calendar-plus', 'f271', '<i class=\'fa fas-calendar-plus\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('calendar-times', 'f273', '<i class=\'fa fas-calendar-times\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('camera', 'f030', '<i class=\'fa fas-camera\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('camera-retro', 'f083', '<i class=\'fa fas-camera-retro\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('capsules', 'f46b', '<i class=\'fa fas-capsules\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('car', 'f1b9', '<i class=\'fa fas-car\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('caret-down', 'f0d7', '<i class=\'fa fas-caret-down\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('caret-left', 'f0d9', '<i class=\'fa fas-caret-left\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('caret-right', 'f0da', '<i class=\'fa fas-caret-right\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('caret-square-down', 'f150', '<i class=\'fa fas-caret-square-down\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('caret-square-left', 'f191', '<i class=\'fa fas-caret-square-left\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('caret-square-right', 'f152', '<i class=\'fa fas-caret-square-right\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('caret-square-up', 'f151', '<i class=\'fa fas-caret-square-up\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('caret-up', 'f0d8', '<i class=\'fa fas-caret-up\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('cart-arrow-down', 'f218', '<i class=\'fa fas-cart-arrow-down\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('cart-plus', 'f217', '<i class=\'fa fas-cart-plus\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('certificate', 'f0a3', '<i class=\'fa fas-certificate\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('chalkboard', 'f51b', '<i class=\'fa fas-chalkboard\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('chalkboard-teacher', 'f51c', '<i class=\'fa fas-chalkboard-teacher\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('chart-area', 'f1fe', '<i class=\'fa fas-chart-area\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('chart-bar', 'f080', '<i class=\'fa fas-chart-bar\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('chart-line', 'f201', '<i class=\'fa fas-chart-line\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('chart-pie', 'f200', '<i class=\'fa fas-chart-pie\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('check', 'f00c', '<i class=\'fa fas-check\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('check-circle', 'f058', '<i class=\'fa fas-check-circle\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('check-square', 'f14a', '<i class=\'fa fas-check-square\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('chess', 'f439', '<i class=\'fa fas-chess\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('chess-bishop', 'f43a', '<i class=\'fa fas-chess-bishop\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('chess-board', 'f43c', '<i class=\'fa fas-chess-board\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('chess-king', 'f43f', '<i class=\'fa fas-chess-king\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('chess-knight', 'f441', '<i class=\'fa fas-chess-knight\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('chess-pawn', 'f443', '<i class=\'fa fas-chess-pawn\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('chess-queen', 'f445', '<i class=\'fa fas-chess-queen\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('chess-rook', 'f447', '<i class=\'fa fas-chess-rook\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('chevron-circle-down', 'f13a', '<i class=\'fa fas-chevron-circle-down\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('chevron-circle-left', 'f137', '<i class=\'fa fas-chevron-circle-left\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('chevron-circle-right', 'f138', '<i class=\'fa fas-chevron-circle-right\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('chevron-circle-up', 'f139', '<i class=\'fa fas-chevron-circle-up\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('chevron-down', 'f078', '<i class=\'fa fas-chevron-down\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('chevron-left', 'f053', '<i class=\'fa fas-chevron-left\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('chevron-right', 'f054', '<i class=\'fa fas-chevron-right\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('chevron-up', 'f077', '<i class=\'fa fas-chevron-up\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('child', 'f1ae', '<i class=\'fa fas-child\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('church', 'f51d', '<i class=\'fa fas-church\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('circle', 'f111', '<i class=\'fa fas-circle\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('circle-notch', 'f1ce', '<i class=\'fa fas-circle-notch\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('clipboard', 'f328', '<i class=\'fa fas-clipboard\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('clipboard-check', 'f46c', '<i class=\'fa fas-clipboard-check\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('clipboard-list', 'f46d', '<i class=\'fa fas-clipboard-list\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('clock', 'f017', '<i class=\'fa fas-clock\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('clone', 'f24d', '<i class=\'fa fas-clone\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('closed-captioning', 'f20a', '<i class=\'fa fas-closed-captioning\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('cloud', 'f0c2', '<i class=\'fa fas-cloud\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('cloud-download-alt', 'f381', '<i class=\'fa fas-cloud-download-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('cloud-upload-alt', 'f382', '<i class=\'fa fas-cloud-upload-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('code', 'f121', '<i class=\'fa fas-code\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('code-branch', 'f126', '<i class=\'fa fas-code-branch\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('coffee', 'f0f4', '<i class=\'fa fas-coffee\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('cog', 'f013', '<i class=\'fa fas-cog\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('cogs', 'f085', '<i class=\'fa fas-cogs\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('coins', 'f51e', '<i class=\'fa fas-coins\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('columns', 'f0db', '<i class=\'fa fas-columns\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('comment', 'f075', '<i class=\'fa fas-comment\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('comment-alt', 'f27a', '<i class=\'fa fas-comment-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('comment-dots', 'f4ad', '<i class=\'fa fas-comment-dots\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('comment-slash', 'f4b3', '<i class=\'fa fas-comment-slash\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('comments', 'f086', '<i class=\'fa fas-comments\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('compact-disc', 'f51f', '<i class=\'fa fas-compact-disc\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('compass', 'f14e', '<i class=\'fa fas-compass\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('compress', 'f066', '<i class=\'fa fas-compress\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('copy', 'f0c5', '<i class=\'fa fas-copy\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('copyright', 'f1f9', '<i class=\'fa fas-copyright\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('couch', 'f4b8', '<i class=\'fa fas-couch\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('credit-card', 'f09d', '<i class=\'fa fas-credit-card\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('crop', 'f125', '<i class=\'fa fas-crop\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('crosshairs', 'f05b', '<i class=\'fa fas-crosshairs\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('crow', 'f520', '<i class=\'fa fas-crow\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('crown', 'f521', '<i class=\'fa fas-crown\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('cube', 'f1b2', '<i class=\'fa fas-cube\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('cubes', 'f1b3', '<i class=\'fa fas-cubes\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('cut', 'f0c4', '<i class=\'fa fas-cut\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('database', 'f1c0', '<i class=\'fa fas-database\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('deaf', 'f2a4', '<i class=\'fa fas-deaf\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('desktop', 'f108', '<i class=\'fa fas-desktop\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('diagnoses', 'f470', '<i class=\'fa fas-diagnoses\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('dice', 'f522', '<i class=\'fa fas-dice\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('dice-five', 'f523', '<i class=\'fa fas-dice-five\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('dice-four', 'f524', '<i class=\'fa fas-dice-four\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('dice-one', 'f525', '<i class=\'fa fas-dice-one\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('dice-six', 'f526', '<i class=\'fa fas-dice-six\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('dice-three', 'f527', '<i class=\'fa fas-dice-three\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('dice-two', 'f528', '<i class=\'fa fas-dice-two\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('divide', 'f529', '<i class=\'fa fas-divide\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('dna', 'f471', '<i class=\'fa fas-dna\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('dollar-sign', 'f155', '<i class=\'fa fas-dollar-sign\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('dolly', 'f472', '<i class=\'fa fas-dolly\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('dolly-flatbed', 'f474', '<i class=\'fa fas-dolly-flatbed\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('donate', 'f4b9', '<i class=\'fa fas-donate\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('door-closed', 'f52a', '<i class=\'fa fas-door-closed\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('door-open', 'f52b', '<i class=\'fa fas-door-open\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('dot-circle', 'f192', '<i class=\'fa fas-dot-circle\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('dove', 'f4ba', '<i class=\'fa fas-dove\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('download', 'f019', '<i class=\'fa fas-download\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('dumbbell', 'f44b', '<i class=\'fa fas-dumbbell\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('edit', 'f044', '<i class=\'fa fas-edit\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('eject', 'f052', '<i class=\'fa fas-eject\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('ellipsis-h', 'f141', '<i class=\'fa fas-ellipsis-h\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('ellipsis-v', 'f142', '<i class=\'fa fas-ellipsis-v\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('envelope', 'f0e0', '<i class=\'fa fas-envelope\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('envelope-open', 'f2b6', '<i class=\'fa fas-envelope-open\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('envelope-square', 'f199', '<i class=\'fa fas-envelope-square\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('equals', 'f52c', '<i class=\'fa fas-equals\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('eraser', 'f12d', '<i class=\'fa fas-eraser\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('euro-sign', 'f153', '<i class=\'fa fas-euro-sign\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('exchange-alt', 'f362', '<i class=\'fa fas-exchange-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('exclamation', 'f12a', '<i class=\'fa fas-exclamation\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('exclamation-circle', 'f06a', '<i class=\'fa fas-exclamation-circle\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('exclamation-triangle', 'f071', '<i class=\'fa fas-exclamation-triangle\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('expand', 'f065', '<i class=\'fa fas-expand\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('expand-arrows-alt', 'f31e', '<i class=\'fa fas-expand-arrows-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('external-link-alt', 'f35d', '<i class=\'fa fas-external-link-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('external-link-square-alt', 'f360', '<i class=\'fa fas-external-link-square-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('eye', 'f06e', '<i class=\'fa fas-eye\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('eye-dropper', 'f1fb', '<i class=\'fa fas-eye-dropper\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('eye-slash', 'f070', '<i class=\'fa fas-eye-slash\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('fast-backward', 'f049', '<i class=\'fa fas-fast-backward\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('fast-forward', 'f050', '<i class=\'fa fas-fast-forward\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('fax', 'f1ac', '<i class=\'fa fas-fax\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('feather', 'f52d', '<i class=\'fa fas-feather\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('female', 'f182', '<i class=\'fa fas-female\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('fighter-jet', 'f0fb', '<i class=\'fa fas-fighter-jet\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('file', 'f15b', '<i class=\'fa fas-file\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('file-alt', 'f15c', '<i class=\'fa fas-file-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('file-archive', 'f1c6', '<i class=\'fa fas-file-archive\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('file-audio', 'f1c7', '<i class=\'fa fas-file-audio\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('file-code', 'f1c9', '<i class=\'fa fas-file-code\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('file-excel', 'f1c3', '<i class=\'fa fas-file-excel\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('file-image', 'f1c5', '<i class=\'fa fas-file-image\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('file-medical', 'f477', '<i class=\'fa fas-file-medical\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('file-medical-alt', 'f478', '<i class=\'fa fas-file-medical-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('file-pdf', 'f1c1', '<i class=\'fa fas-file-pdf\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('file-powerpoint', 'f1c4', '<i class=\'fa fas-file-powerpoint\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('file-video', 'f1c8', '<i class=\'fa fas-file-video\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('file-word', 'f1c2', '<i class=\'fa fas-file-word\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('film', 'f008', '<i class=\'fa fas-film\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('filter', 'f0b0', '<i class=\'fa fas-filter\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('fire', 'f06d', '<i class=\'fa fas-fire\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('fire-extinguisher', 'f134', '<i class=\'fa fas-fire-extinguisher\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('first-aid', 'f479', '<i class=\'fa fas-first-aid\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('flag', 'f024', '<i class=\'fa fas-flag\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('flag-checkered', 'f11e', '<i class=\'fa fas-flag-checkered\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('flask', 'f0c3', '<i class=\'fa fas-flask\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('folder', 'f07b', '<i class=\'fa fas-folder\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('folder-open', 'f07c', '<i class=\'fa fas-folder-open\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('font', 'f031', '<i class=\'fa fas-font\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('font-awesome-logo-full', 'f4e6', '<i class=\'fa fas-font-awesome-logo-full\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('football-ball', 'f44e', '<i class=\'fa fas-football-ball\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('forward', 'f04e', '<i class=\'fa fas-forward\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('frog', 'f52e', '<i class=\'fa fas-frog\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('frown', 'f119', '<i class=\'fa fas-frown\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('futbol', 'f1e3', '<i class=\'fa fas-futbol\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('gamepad', 'f11b', '<i class=\'fa fas-gamepad\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('gas-pump', 'f52f', '<i class=\'fa fas-gas-pump\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('gavel', 'f0e3', '<i class=\'fa fas-gavel\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('gem', 'f3a5', '<i class=\'fa fas-gem\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('genderless', 'f22d', '<i class=\'fa fas-genderless\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('gift', 'f06b', '<i class=\'fa fas-gift\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('glass-martini', 'f000', '<i class=\'fa fas-glass-martini\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('glasses', 'f530', '<i class=\'fa fas-glasses\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('globe', 'f0ac', '<i class=\'fa fas-globe\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('golf-ball', 'f450', '<i class=\'fa fas-golf-ball\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('graduation-cap', 'f19d', '<i class=\'fa fas-graduation-cap\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('greater-than', 'f531', '<i class=\'fa fas-greater-than\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('greater-than-equal', 'f532', '<i class=\'fa fas-greater-than-equal\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('h-square', 'f0fd', '<i class=\'fa fas-h-square\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('hand-holding', 'f4bd', '<i class=\'fa fas-hand-holding\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('hand-holding-heart', 'f4be', '<i class=\'fa fas-hand-holding-heart\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('hand-holding-usd', 'f4c0', '<i class=\'fa fas-hand-holding-usd\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('hand-lizard', 'f258', '<i class=\'fa fas-hand-lizard\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('hand-paper', 'f256', '<i class=\'fa fas-hand-paper\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('hand-peace', 'f25b', '<i class=\'fa fas-hand-peace\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('hand-point-down', 'f0a7', '<i class=\'fa fas-hand-point-down\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('hand-point-left', 'f0a5', '<i class=\'fa fas-hand-point-left\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('hand-point-right', 'f0a4', '<i class=\'fa fas-hand-point-right\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('hand-point-up', 'f0a6', '<i class=\'fa fas-hand-point-up\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('hand-pointer', 'f25a', '<i class=\'fa fas-hand-pointer\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('hand-rock', 'f255', '<i class=\'fa fas-hand-rock\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('hand-scissors', 'f257', '<i class=\'fa fas-hand-scissors\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('hand-spock', 'f259', '<i class=\'fa fas-hand-spock\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('hands', 'f4c2', '<i class=\'fa fas-hands\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('hands-helping', 'f4c4', '<i class=\'fa fas-hands-helping\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('handshake', 'f2b5', '<i class=\'fa fas-handshake\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('hashtag', 'f292', '<i class=\'fa fas-hashtag\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('hdd', 'f0a0', '<i class=\'fa fas-hdd\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('heading', 'f1dc', '<i class=\'fa fas-heading\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('headphones', 'f025', '<i class=\'fa fas-headphones\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('heart', 'f004', '<i class=\'fa fas-heart\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('heartbeat', 'f21e', '<i class=\'fa fas-heartbeat\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('helicopter', 'f533', '<i class=\'fa fas-helicopter\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('history', 'f1da', '<i class=\'fa fas-history\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('hockey-puck', 'f453', '<i class=\'fa fas-hockey-puck\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('home', 'f015', '<i class=\'fa fas-home\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('hospital', 'f0f8', '<i class=\'fa fas-hospital\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('hospital-alt', 'f47d', '<i class=\'fa fas-hospital-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('hospital-symbol', 'f47e', '<i class=\'fa fas-hospital-symbol\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('hourglass', 'f254', '<i class=\'fa fas-hourglass\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('hourglass-end', 'f253', '<i class=\'fa fas-hourglass-end\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('hourglass-half', 'f252', '<i class=\'fa fas-hourglass-half\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('hourglass-start', 'f251', '<i class=\'fa fas-hourglass-start\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('i-cursor', 'f246', '<i class=\'fa fas-i-cursor\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('id-badge', 'f2c1', '<i class=\'fa fas-id-badge\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('id-card', 'f2c2', '<i class=\'fa fas-id-card\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('id-card-alt', 'f47f', '<i class=\'fa fas-id-card-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('image', 'f03e', '<i class=\'fa fas-image\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('images', 'f302', '<i class=\'fa fas-images\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('inbox', 'f01c', '<i class=\'fa fas-inbox\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('indent', 'f03c', '<i class=\'fa fas-indent\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('industry', 'f275', '<i class=\'fa fas-industry\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('infinity', 'f534', '<i class=\'fa fas-infinity\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('info', 'f129', '<i class=\'fa fas-info\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('info-circle', 'f05a', '<i class=\'fa fas-info-circle\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('italic', 'f033', '<i class=\'fa fas-italic\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('key', 'f084', '<i class=\'fa fas-key\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('keyboard', 'f11c', '<i class=\'fa fas-keyboard\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('kiwi-bird', 'f535', '<i class=\'fa fas-kiwi-bird\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('language', 'f1ab', '<i class=\'fa fas-language\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('laptop', 'f109', '<i class=\'fa fas-laptop\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('leaf', 'f06c', '<i class=\'fa fas-leaf\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('lemon', 'f094', '<i class=\'fa fas-lemon\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('less-than', 'f536', '<i class=\'fa fas-less-than\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('less-than-equal', 'f537', '<i class=\'fa fas-less-than-equal\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('level-down-alt', 'f3be', '<i class=\'fa fas-level-down-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('level-up-alt', 'f3bf', '<i class=\'fa fas-level-up-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('life-ring', 'f1cd', '<i class=\'fa fas-life-ring\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('lightbulb', 'f0eb', '<i class=\'fa fas-lightbulb\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('link', 'f0c1', '<i class=\'fa fas-link\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('lira-sign', 'f195', '<i class=\'fa fas-lira-sign\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('list', 'f03a', '<i class=\'fa fas-list\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('list-alt', 'f022', '<i class=\'fa fas-list-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('list-ol', 'f0cb', '<i class=\'fa fas-list-ol\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('list-ul', 'f0ca', '<i class=\'fa fas-list-ul\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('location-arrow', 'f124', '<i class=\'fa fas-location-arrow\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('lock', 'f023', '<i class=\'fa fas-lock\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('lock-open', 'f3c1', '<i class=\'fa fas-lock-open\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('long-arrow-alt-down', 'f309', '<i class=\'fa fas-long-arrow-alt-down\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('long-arrow-alt-left', 'f30a', '<i class=\'fa fas-long-arrow-alt-left\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('long-arrow-alt-right', 'f30b', '<i class=\'fa fas-long-arrow-alt-right\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('long-arrow-alt-up', 'f30c', '<i class=\'fa fas-long-arrow-alt-up\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('low-vision', 'f2a8', '<i class=\'fa fas-low-vision\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('magic', 'f0d0', '<i class=\'fa fas-magic\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('magnet', 'f076', '<i class=\'fa fas-magnet\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('male', 'f183', '<i class=\'fa fas-male\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('map', 'f279', '<i class=\'fa fas-map\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('map-marker', 'f041', '<i class=\'fa fas-map-marker\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('map-marker-alt', 'f3c5', '<i class=\'fa fas-map-marker-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('map-pin', 'f276', '<i class=\'fa fas-map-pin\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('map-signs', 'f277', '<i class=\'fa fas-map-signs\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('mars', 'f222', '<i class=\'fa fas-mars\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('mars-double', 'f227', '<i class=\'fa fas-mars-double\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('mars-stroke', 'f229', '<i class=\'fa fas-mars-stroke\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('mars-stroke-h', 'f22b', '<i class=\'fa fas-mars-stroke-h\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('mars-stroke-v', 'f22a', '<i class=\'fa fas-mars-stroke-v\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('medkit', 'f0fa', '<i class=\'fa fas-medkit\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('meh', 'f11a', '<i class=\'fa fas-meh\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('memory', 'f538', '<i class=\'fa fas-memory\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('mercury', 'f223', '<i class=\'fa fas-mercury\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('microchip', 'f2db', '<i class=\'fa fas-microchip\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('microphone', 'f130', '<i class=\'fa fas-microphone\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('microphone-alt', 'f3c9', '<i class=\'fa fas-microphone-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('microphone-alt-slash', 'f539', '<i class=\'fa fas-microphone-alt-slash\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('microphone-slash', 'f131', '<i class=\'fa fas-microphone-slash\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('minus', 'f068', '<i class=\'fa fas-minus\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('minus-circle', 'f056', '<i class=\'fa fas-minus-circle\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('minus-square', 'f146', '<i class=\'fa fas-minus-square\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('mobile', 'f10b', '<i class=\'fa fas-mobile\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('mobile-alt', 'f3cd', '<i class=\'fa fas-mobile-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('money-bill', 'f0d6', '<i class=\'fa fas-money-bill\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('money-bill-alt', 'f3d1', '<i class=\'fa fas-money-bill-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('money-bill-wave', 'f53a', '<i class=\'fa fas-money-bill-wave\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('money-bill-wave-alt', 'f53b', '<i class=\'fa fas-money-bill-wave-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('money-check', 'f53c', '<i class=\'fa fas-money-check\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('money-check-alt', 'f53d', '<i class=\'fa fas-money-check-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('moon', 'f186', '<i class=\'fa fas-moon\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('motorcycle', 'f21c', '<i class=\'fa fas-motorcycle\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('mouse-pointer', 'f245', '<i class=\'fa fas-mouse-pointer\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('music', 'f001', '<i class=\'fa fas-music\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('neuter', 'f22c', '<i class=\'fa fas-neuter\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('newspaper', 'f1ea', '<i class=\'fa fas-newspaper\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('not-equal', 'f53e', '<i class=\'fa fas-not-equal\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('notes-medical', 'f481', '<i class=\'fa fas-notes-medical\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('object-group', 'f247', '<i class=\'fa fas-object-group\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('object-ungroup', 'f248', '<i class=\'fa fas-object-ungroup\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('outdent', 'f03b', '<i class=\'fa fas-outdent\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('paint-brush', 'f1fc', '<i class=\'fa fas-paint-brush\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('palette', 'f53f', '<i class=\'fa fas-palette\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('pallet', 'f482', '<i class=\'fa fas-pallet\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('paper-plane', 'f1d8', '<i class=\'fa fas-paper-plane\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('paperclip', 'f0c6', '<i class=\'fa fas-paperclip\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('parachute-box', 'f4cd', '<i class=\'fa fas-parachute-box\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('paragraph', 'f1dd', '<i class=\'fa fas-paragraph\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('parking', 'f540', '<i class=\'fa fas-parking\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('paste', 'f0ea', '<i class=\'fa fas-paste\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('pause', 'f04c', '<i class=\'fa fas-pause\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('pause-circle', 'f28b', '<i class=\'fa fas-pause-circle\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('paw', 'f1b0', '<i class=\'fa fas-paw\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('pen-square', 'f14b', '<i class=\'fa fas-pen-square\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('pencil-alt', 'f303', '<i class=\'fa fas-pencil-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('people-carry', 'f4ce', '<i class=\'fa fas-people-carry\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('percent', 'f295', '<i class=\'fa fas-percent\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('percentage', 'f541', '<i class=\'fa fas-percentage\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('phone', 'f095', '<i class=\'fa fas-phone\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('phone-slash', 'f3dd', '<i class=\'fa fas-phone-slash\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('phone-square', 'f098', '<i class=\'fa fas-phone-square\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('phone-volume', 'f2a0', '<i class=\'fa fas-phone-volume\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('piggy-bank', 'f4d3', '<i class=\'fa fas-piggy-bank\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('pills', 'f484', '<i class=\'fa fas-pills\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('plane', 'f072', '<i class=\'fa fas-plane\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('play', 'f04b', '<i class=\'fa fas-play\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('play-circle', 'f144', '<i class=\'fa fas-play-circle\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('plug', 'f1e6', '<i class=\'fa fas-plug\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('plus', 'f067', '<i class=\'fa fas-plus\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('plus-circle', 'f055', '<i class=\'fa fas-plus-circle\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('plus-square', 'f0fe', '<i class=\'fa fas-plus-square\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('podcast', 'f2ce', '<i class=\'fa fas-podcast\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('poo', 'f2fe', '<i class=\'fa fas-poo\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('portrait', 'f3e0', '<i class=\'fa fas-portrait\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('pound-sign', 'f154', '<i class=\'fa fas-pound-sign\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('power-off', 'f011', '<i class=\'fa fas-power-off\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('prescription-bottle', 'f485', '<i class=\'fa fas-prescription-bottle\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('prescription-bottle-alt', 'f486', '<i class=\'fa fas-prescription-bottle-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('print', 'f02f', '<i class=\'fa fas-print\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('procedures', 'f487', '<i class=\'fa fas-procedures\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('project-diagram', 'f542', '<i class=\'fa fas-project-diagram\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('puzzle-piece', 'f12e', '<i class=\'fa fas-puzzle-piece\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('qrcode', 'f029', '<i class=\'fa fas-qrcode\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('question', 'f128', '<i class=\'fa fas-question\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('question-circle', 'f059', '<i class=\'fa fas-question-circle\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('quidditch', 'f458', '<i class=\'fa fas-quidditch\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('quote-left', 'f10d', '<i class=\'fa fas-quote-left\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('quote-right', 'f10e', '<i class=\'fa fas-quote-right\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('random', 'f074', '<i class=\'fa fas-random\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('receipt', 'f543', '<i class=\'fa fas-receipt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('recycle', 'f1b8', '<i class=\'fa fas-recycle\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('redo', 'f01e', '<i class=\'fa fas-redo\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('redo-alt', 'f2f9', '<i class=\'fa fas-redo-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('registered', 'f25d', '<i class=\'fa fas-registered\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('reply', 'f3e5', '<i class=\'fa fas-reply\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('reply-all', 'f122', '<i class=\'fa fas-reply-all\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('retweet', 'f079', '<i class=\'fa fas-retweet\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('ribbon', 'f4d6', '<i class=\'fa fas-ribbon\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('road', 'f018', '<i class=\'fa fas-road\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('robot', 'f544', '<i class=\'fa fas-robot\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('rocket', 'f135', '<i class=\'fa fas-rocket\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('rss', 'f09e', '<i class=\'fa fas-rss\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('rss-square', 'f143', '<i class=\'fa fas-rss-square\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('ruble-sign', 'f158', '<i class=\'fa fas-ruble-sign\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('ruler', 'f545', '<i class=\'fa fas-ruler\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('ruler-combined', 'f546', '<i class=\'fa fas-ruler-combined\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('ruler-horizontal', 'f547', '<i class=\'fa fas-ruler-horizontal\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('ruler-vertical', 'f548', '<i class=\'fa fas-ruler-vertical\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('rupee-sign', 'f156', '<i class=\'fa fas-rupee-sign\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('save', 'f0c7', '<i class=\'fa fas-save\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('school', 'f549', '<i class=\'fa fas-school\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('screwdriver', 'f54a', '<i class=\'fa fas-screwdriver\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('search', 'f002', '<i class=\'fa fas-search\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('search-minus', 'f010', '<i class=\'fa fas-search-minus\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('search-plus', 'f00e', '<i class=\'fa fas-search-plus\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('seedling', 'f4d8', '<i class=\'fa fas-seedling\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('server', 'f233', '<i class=\'fa fas-server\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('share', 'f064', '<i class=\'fa fas-share\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('share-alt', 'f1e0', '<i class=\'fa fas-share-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('share-alt-square', 'f1e1', '<i class=\'fa fas-share-alt-square\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('share-square', 'f14d', '<i class=\'fa fas-share-square\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('shekel-sign', 'f20b', '<i class=\'fa fas-shekel-sign\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('shield-alt', 'f3ed', '<i class=\'fa fas-shield-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('ship', 'f21a', '<i class=\'fa fas-ship\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('shipping-fast', 'f48b', '<i class=\'fa fas-shipping-fast\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('shoe-prints', 'f54b', '<i class=\'fa fas-shoe-prints\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('shopping-bag', 'f290', '<i class=\'fa fas-shopping-bag\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('shopping-basket', 'f291', '<i class=\'fa fas-shopping-basket\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('shopping-cart', 'f07a', '<i class=\'fa fas-shopping-cart\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('shower', 'f2cc', '<i class=\'fa fas-shower\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('sign', 'f4d9', '<i class=\'fa fas-sign\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('sign-in-alt', 'f2f6', '<i class=\'fa fas-sign-in-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('sign-language', 'f2a7', '<i class=\'fa fas-sign-language\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('sign-out-alt', 'f2f5', '<i class=\'fa fas-sign-out-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('signal', 'f012', '<i class=\'fa fas-signal\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('sitemap', 'f0e8', '<i class=\'fa fas-sitemap\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('skull', 'f54c', '<i class=\'fa fas-skull\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('sliders-h', 'f1de', '<i class=\'fa fas-sliders-h\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('smile', 'f118', '<i class=\'fa fas-smile\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('smoking', 'f48d', '<i class=\'fa fas-smoking\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('smoking-ban', 'f54d', '<i class=\'fa fas-smoking-ban\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('snowflake', 'f2dc', '<i class=\'fa fas-snowflake\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('sort', 'f0dc', '<i class=\'fa fas-sort\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('sort-alpha-down', 'f15d', '<i class=\'fa fas-sort-alpha-down\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('sort-alpha-up', 'f15e', '<i class=\'fa fas-sort-alpha-up\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('sort-amount-down', 'f160', '<i class=\'fa fas-sort-amount-down\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('sort-amount-up', 'f161', '<i class=\'fa fas-sort-amount-up\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('sort-down', 'f0dd', '<i class=\'fa fas-sort-down\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('sort-numeric-down', 'f162', '<i class=\'fa fas-sort-numeric-down\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('sort-numeric-up', 'f163', '<i class=\'fa fas-sort-numeric-up\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('sort-up', 'f0de', '<i class=\'fa fas-sort-up\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('space-shuttle', 'f197', '<i class=\'fa fas-space-shuttle\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('spinner', 'f110', '<i class=\'fa fas-spinner\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('square', 'f0c8', '<i class=\'fa fas-square\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('square-full', 'f45c', '<i class=\'fa fas-square-full\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('star', 'f005', '<i class=\'fa fas-star\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('star-half', 'f089', '<i class=\'fa fas-star-half\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('step-backward', 'f048', '<i class=\'fa fas-step-backward\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('step-forward', 'f051', '<i class=\'fa fas-step-forward\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('stethoscope', 'f0f1', '<i class=\'fa fas-stethoscope\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('sticky-note', 'f249', '<i class=\'fa fas-sticky-note\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('stop', 'f04d', '<i class=\'fa fas-stop\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('stop-circle', 'f28d', '<i class=\'fa fas-stop-circle\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('stopwatch', 'f2f2', '<i class=\'fa fas-stopwatch\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('store', 'f54e', '<i class=\'fa fas-store\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('store-alt', 'f54f', '<i class=\'fa fas-store-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('stream', 'f550', '<i class=\'fa fas-stream\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('street-view', 'f21d', '<i class=\'fa fas-street-view\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('strikethrough', 'f0cc', '<i class=\'fa fas-strikethrough\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('stroopwafel', 'f551', '<i class=\'fa fas-stroopwafel\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('subscript', 'f12c', '<i class=\'fa fas-subscript\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('subway', 'f239', '<i class=\'fa fas-subway\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('suitcase', 'f0f2', '<i class=\'fa fas-suitcase\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('sun', 'f185', '<i class=\'fa fas-sun\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('superscript', 'f12b', '<i class=\'fa fas-superscript\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('sync', 'f021', '<i class=\'fa fas-sync\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('sync-alt', 'f2f1', '<i class=\'fa fas-sync-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('syringe', 'f48e', '<i class=\'fa fas-syringe\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('table', 'f0ce', '<i class=\'fa fas-table\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('table-tennis', 'f45d', '<i class=\'fa fas-table-tennis\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('tablet', 'f10a', '<i class=\'fa fas-tablet\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('tablet-alt', 'f3fa', '<i class=\'fa fas-tablet-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('tablets', 'f490', '<i class=\'fa fas-tablets\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('tachometer-alt', 'f3fd', '<i class=\'fa fas-tachometer-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('tag', 'f02b', '<i class=\'fa fas-tag\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('tags', 'f02c', '<i class=\'fa fas-tags\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('tape', 'f4db', '<i class=\'fa fas-tape\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('tasks', 'f0ae', '<i class=\'fa fas-tasks\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('taxi', 'f1ba', '<i class=\'fa fas-taxi\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('terminal', 'f120', '<i class=\'fa fas-terminal\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('text-height', 'f034', '<i class=\'fa fas-text-height\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('text-width', 'f035', '<i class=\'fa fas-text-width\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('th', 'f00a', '<i class=\'fa fas-th\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('th-large', 'f009', '<i class=\'fa fas-th-large\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('th-list', 'f00b', '<i class=\'fa fas-th-list\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('thermometer', 'f491', '<i class=\'fa fas-thermometer\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('thermometer-empty', 'f2cb', '<i class=\'fa fas-thermometer-empty\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('thermometer-full', 'f2c7', '<i class=\'fa fas-thermometer-full\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('thermometer-half', 'f2c9', '<i class=\'fa fas-thermometer-half\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('thermometer-quarter', 'f2ca', '<i class=\'fa fas-thermometer-quarter\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('thermometer-three-quarters', 'f2c8', '<i class=\'fa fas-thermometer-three-quarters\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('thumbs-down', 'f165', '<i class=\'fa fas-thumbs-down\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('thumbs-up', 'f164', '<i class=\'fa fas-thumbs-up\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('thumbtack', 'f08d', '<i class=\'fa fas-thumbtack\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('ticket-alt', 'f3ff', '<i class=\'fa fas-ticket-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('times', 'f00d', '<i class=\'fa fas-times\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('times-circle', 'f057', '<i class=\'fa fas-times-circle\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('tint', 'f043', '<i class=\'fa fas-tint\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('toggle-off', 'f204', '<i class=\'fa fas-toggle-off\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('toggle-on', 'f205', '<i class=\'fa fas-toggle-on\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('toolbox', 'f552', '<i class=\'fa fas-toolbox\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('trademark', 'f25c', '<i class=\'fa fas-trademark\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('train', 'f238', '<i class=\'fa fas-train\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('transgender', 'f224', '<i class=\'fa fas-transgender\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('transgender-alt', 'f225', '<i class=\'fa fas-transgender-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('trash', 'f1f8', '<i class=\'fa fas-trash\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('trash-alt', 'f2ed', '<i class=\'fa fas-trash-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('tree', 'f1bb', '<i class=\'fa fas-tree\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('trophy', 'f091', '<i class=\'fa fas-trophy\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('truck', 'f0d1', '<i class=\'fa fas-truck\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('truck-loading', 'f4de', '<i class=\'fa fas-truck-loading\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('truck-moving', 'f4df', '<i class=\'fa fas-truck-moving\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('tshirt', 'f553', '<i class=\'fa fas-tshirt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('tty', 'f1e4', '<i class=\'fa fas-tty\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('tv', 'f26c', '<i class=\'fa fas-tv\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('umbrella', 'f0e9', '<i class=\'fa fas-umbrella\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('underline', 'f0cd', '<i class=\'fa fas-underline\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('undo', 'f0e2', '<i class=\'fa fas-undo\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('undo-alt', 'f2ea', '<i class=\'fa fas-undo-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('universal-access', 'f29a', '<i class=\'fa fas-universal-access\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('university', 'f19c', '<i class=\'fa fas-university\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('unlink', 'f127', '<i class=\'fa fas-unlink\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('unlock', 'f09c', '<i class=\'fa fas-unlock\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('unlock-alt', 'f13e', '<i class=\'fa fas-unlock-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('upload', 'f093', '<i class=\'fa fas-upload\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('user', 'f007', '<i class=\'fa fas-user\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('user-alt', 'f406', '<i class=\'fa fas-user-alt\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('user-alt-slash', 'f4fa', '<i class=\'fa fas-user-alt-slash\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('user-astronaut', 'f4fb', '<i class=\'fa fas-user-astronaut\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('user-check', 'f4fc', '<i class=\'fa fas-user-check\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('user-circle', 'f2bd', '<i class=\'fa fas-user-circle\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('user-clock', 'f4fd', '<i class=\'fa fas-user-clock\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('user-cog', 'f4fe', '<i class=\'fa fas-user-cog\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('user-edit', 'f4ff', '<i class=\'fa fas-user-edit\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('user-friends', 'f500', '<i class=\'fa fas-user-friends\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('user-graduate', 'f501', '<i class=\'fa fas-user-graduate\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('user-lock', 'f502', '<i class=\'fa fas-user-lock\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('user-md', 'f0f0', '<i class=\'fa fas-user-md\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('user-minus', 'f503', '<i class=\'fa fas-user-minus\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('user-ninja', 'f504', '<i class=\'fa fas-user-ninja\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('user-plus', 'f234', '<i class=\'fa fas-user-plus\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('user-secret', 'f21b', '<i class=\'fa fas-user-secret\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('user-shield', 'f505', '<i class=\'fa fas-user-shield\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('user-slash', 'f506', '<i class=\'fa fas-user-slash\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('user-tag', 'f507', '<i class=\'fa fas-user-tag\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('user-tie', 'f508', '<i class=\'fa fas-user-tie\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('user-times', 'f235', '<i class=\'fa fas-user-times\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('users', 'f0c0', '<i class=\'fa fas-users\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('users-cog', 'f509', '<i class=\'fa fas-users-cog\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('utensil-spoon', 'f2e5', '<i class=\'fa fas-utensil-spoon\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('utensils', 'f2e7', '<i class=\'fa fas-utensils\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('venus', 'f221', '<i class=\'fa fas-venus\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('venus-double', 'f226', '<i class=\'fa fas-venus-double\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('venus-mars', 'f228', '<i class=\'fa fas-venus-mars\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('vial', 'f492', '<i class=\'fa fas-vial\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('vials', 'f493', '<i class=\'fa fas-vials\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('video', 'f03d', '<i class=\'fa fas-video\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('video-slash', 'f4e2', '<i class=\'fa fas-video-slash\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('volleyball-ball', 'f45f', '<i class=\'fa fas-volleyball-ball\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('volume-down', 'f027', '<i class=\'fa fas-volume-down\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('volume-off', 'f026', '<i class=\'fa fas-volume-off\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('volume-up', 'f028', '<i class=\'fa fas-volume-up\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('walking', 'f554', '<i class=\'fa fas-walking\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('wallet', 'f555', '<i class=\'fa fas-wallet\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('warehouse', 'f494', '<i class=\'fa fas-warehouse\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('weight', 'f496', '<i class=\'fa fas-weight\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('wheelchair', 'f193', '<i class=\'fa fas-wheelchair\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('wifi', 'f1eb', '<i class=\'fa fas-wifi\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('window-close', 'f410', '<i class=\'fa fas-window-close\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('window-maximize', 'f2d0', '<i class=\'fa fas-window-maximize\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('window-minimize', 'f2d1', '<i class=\'fa fas-window-minimize\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('window-restore', 'f2d2', '<i class=\'fa fas-window-restore\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('wine-glass', 'f4e3', '<i class=\'fa fas-wine-glass\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('won-sign', 'f159', '<i class=\'fa fas-won-sign\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('wrench', 'f0ad', '<i class=\'fa fas-wrench\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('x-ray', 'f497', '<i class=\'fa fas-x-ray\'></i>');
INSERT INTO `font_awesome_icon` (`icon`, `unicode`, `html`) VALUES ('yen-sign', 'f157', '<i class=\'fa fas-yen-sign\'></i>');


#
# TABLE STRUCTURE FOR: icon
#

DROP TABLE IF EXISTS `icon`;

CREATE TABLE `icon` (
  `id` int(11) DEFAULT NULL,
  `icons_icon_tags` varchar(25) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (359, 'social_youtube_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (358, 'social_youtube_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (357, 'social_youtube');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (356, 'social_wordpress_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (355, 'social_wordpress_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (354, 'social_wordpress');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (353, 'social_vimeo_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (352, 'social_vimeo_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (351, 'social_vimeo');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (350, 'social_twitter_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (349, 'social_twitter_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (348, 'social_twitter');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (347, 'social_tumblr_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (346, 'social_tumblr_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (345, 'social_tumblr');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (344, 'social_tumbleupon');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (343, 'social_stumbleupon_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (342, 'social_stumbleupon_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (341, 'social_spotify_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (340, 'social_spotify_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (339, 'social_spotify');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (338, 'social_skype_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (337, 'social_skype_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (336, 'social_skype');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (335, 'social_share_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (334, 'social_share_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (333, 'social_share');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (332, 'social_rss_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (331, 'social_rss_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (330, 'social_rss');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (329, 'social_pinterest_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (328, 'social_pinterest_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (327, 'social_pinterest');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (326, 'social_picassa_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (325, 'social_picassa_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (324, 'social_picassa');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (323, 'social_myspace_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (322, 'social_myspace_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (321, 'social_myspace');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (320, 'social_linkedin_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (319, 'social_linkedin_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (318, 'social_linkedin');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (317, 'social_instagram_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (316, 'social_instagram_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (315, 'social_instagram');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (314, 'social_googleplus_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (313, 'social_googleplus_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (312, 'social_googleplus');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (311, 'social_googledrive_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (310, 'social_googledrive_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (309, 'social_googledrive');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (308, 'social_flickr_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (307, 'social_flickr_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (306, 'social_flickr');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (305, 'social_facebook_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (304, 'social_facebook_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (303, 'social_facebook');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (302, 'social_dribbble_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (301, 'social_dribbble_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (300, 'social_dribbble');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (299, 'social_deviantart_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (298, 'social_deviantart_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (297, 'social_deviantart');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (296, 'social_delicious_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (295, 'social_delicious_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (294, 'social_delicious');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (293, 'social_blogger_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (292, 'social_blogger_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (291, 'social_blogger');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (290, 'icon_upload');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (289, 'icon_trash');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (288, 'icon_toolbox');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (287, 'icon_tags');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (286, 'icon_tag');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (285, 'icon_ribbon');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (284, 'icon_quotations_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (283, 'icon_pushpin');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (282, 'icon_profile');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (281, 'icon_pin');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (280, 'icon_phone');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (279, 'icon_pause_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (278, 'icon_music');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (277, 'icon_mic');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (276, 'icon_map');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (275, 'icon_mail');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (274, 'icon_lock-open');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (273, 'icon_lock');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (272, 'icon_lightbulb');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (271, 'icon_key');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (270, 'icon_house');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (269, 'icon_heart');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (268, 'icon_group');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (267, 'icon_grid-3x3');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (266, 'icon_grid-2x2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (265, 'icon_gift');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (264, 'icon_drawer');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (263, 'icon_download');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (262, 'icon_cursor');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (261, 'icon_contacts');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (260, 'icon_cone');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (259, 'icon_compass');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (258, 'icon_cloud-upload');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (257, 'icon_cloud-download');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (256, 'icon_cloud');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (255, 'icon_clock');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (254, 'icon_cart');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (253, 'icon_camera');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (252, 'icon_book');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (251, 'icon_bag');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (250, 'icon_archive');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (249, 'icon_zoom-out');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (248, 'icon_zoom-in');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (247, 'icon_volume-low_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (246, 'icon_volume-low');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (245, 'icon_volume-high_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (244, 'icon_volume-high');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (243, 'icon_vol-mute_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (242, 'icon_vol-mute');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (241, 'icon_trash_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (240, 'icon_tools');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (239, 'icon_toolbox_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (238, 'icon_tool');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (237, 'icon_tags_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (236, 'icon_tag_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (235, 'icon_tablet');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (234, 'icon_table');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (233, 'icon_stop_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (232, 'icon_star-half_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (231, 'icon_star-half');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (230, 'icon_star_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (229, 'icon_star');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (228, 'icon_ribbon_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (227, 'icon_refresh');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (226, 'icon_quotations_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (225, 'icon_quotations');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (224, 'icon_question_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (223, 'icon_question_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (222, 'icon_question');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (221, 'icon_pushpin_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (220, 'icon_plus_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (219, 'icon_pin_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (218, 'icon_piechart');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (217, 'icon_pencil_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (216, 'icon_paperclip');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (215, 'icon_mobile');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (214, 'icon_minus_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (213, 'icon_mic_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (212, 'icon_menu-square_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (211, 'icon_menu-circle_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (210, 'icon_map_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (209, 'icon_mail_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (208, 'icon_lock-open_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (207, 'icon_lock_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (206, 'icon_loading');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (205, 'icon_link_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (204, 'icon_link');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (203, 'icon_lightbulb_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (202, 'icon_lifesaver');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (201, 'icon_laptop');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (200, 'icon_key_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (199, 'icon_info');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (198, 'icon_images');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (197, 'icon_image');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (196, 'icon_house_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (195, 'icon_heart_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (194, 'icon_headphones');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (193, 'icon_gift_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (192, 'icon_genius');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (191, 'icon_folder-open');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (190, 'icon_folder-add');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (189, 'icon_folder_upload');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (188, 'icon_folder_download');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (187, 'icon_folder');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (186, 'icon_film');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (185, 'icon_error-triangle_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (184, 'icon_error-triangle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (183, 'icon_error-oct');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (182, 'icon_error-circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (181, 'icon_drawer_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (180, 'icon_documents');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (179, 'icon_document');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (178, 'icon_desktop');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (177, 'icon_cursor_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (176, 'icon_creditcard');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (175, 'icon_contacts_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (174, 'icon_cone_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (173, 'icon_compass_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (172, 'icon_comment_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (171, 'icon_comment');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (170, 'icon_cogs');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (169, 'icon_cog');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (168, 'icon_cloud-upload_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (167, 'icon_cloud-download_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (166, 'icon_cloud_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (165, 'icon_close_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (164, 'icon_clock_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (163, 'icon_check_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (162, 'icon_chat_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (161, 'icon_chat');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (160, 'icon_cart_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (159, 'icon_camera_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (158, 'icon_calendar');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (157, 'icon_book_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (156, 'icon_blocked');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (155, 'icon_bag_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (154, 'icon_archive_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (153, 'arrow_up_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (152, 'arrow_triangle-up_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (151, 'arrow_triangle-right_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (150, 'arrow_triangle-left_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (149, 'arrow_triangle-down_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (148, 'arrow_right-up_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (147, 'arrow_right-down_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (146, 'arrow_right_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (145, 'arrow_left-up_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (144, 'arrow_left-down_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (143, 'arrow_left_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (142, 'arrow_expand_alt3');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (141, 'arrow_down_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (140, 'arrow_condense_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (139, 'arrow_carrot-right_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (138, 'arrow_carrot-left_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (137, 'arrow_carrot-down_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (136, 'arrow_carrot-2up_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (135, 'arrow_carrot-2right_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (134, 'arrow_carrot-2left_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (133, 'arrow_carrot-2dwnn_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (132, 'arrow_carrot_up_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (131, 'icon_zoom-out_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (130, 'icon_zoom-in_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (129, 'icon_wallet');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (128, 'icon_ul');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (127, 'icon_target');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (126, 'icon_stop_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (125, 'icon_stop');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (124, 'icon_shield');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (123, 'icon_search2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (122, 'icon_search_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (121, 'icon_search');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (120, 'icon_rook');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (119, 'icon_puzzle_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (118, 'icon_puzzle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (117, 'icon_printer-alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (116, 'icon_printer');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (115, 'icon_plus-box');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (114, 'icon_plus_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (113, 'icon_plus');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (112, 'icon_percent');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (111, 'icon_pens');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (110, 'icon_pencil-edit_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (109, 'icon_pencil-edit');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (108, 'icon_pencil');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (107, 'icon_pause_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (106, 'icon_pause');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (105, 'icon_ol');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (104, 'icon_mug');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (103, 'icon_minus-box');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (102, 'icon_minus-06');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (101, 'icon_minus_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (100, 'icon_menu-square_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (99, 'icon_menu-circle_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (98, 'icon_menu');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (97, 'icon_like');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (96, 'icon_info_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (95, 'icon_id-2_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (94, 'icon_id-2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (93, 'icon_id_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (92, 'icon_id');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (91, 'icon_hourglass');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (90, 'icon_globe-2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (89, 'icon_globe');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (88, 'icon_folder-open_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (87, 'icon_folder-alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (86, 'icon_folder-add_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (85, 'icon_flowchart');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (84, 'icon_floppy_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (83, 'icon_floppy');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (82, 'icon_error-oct_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (81, 'icon_error-circle_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (80, 'icon_easel');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (79, 'icon_drive_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (78, 'icon_drive');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (77, 'icon_documents_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (76, 'icon_document_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (75, 'icon_dislike_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (74, 'icon_dislike');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (73, 'icon_datareport_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (72, 'icon_datareport');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (71, 'icon_currency_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (70, 'icon_currency');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (69, 'icon_close_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (68, 'icon_close');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (67, 'icon_clipboard');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (66, 'icon_circle-slelected');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (65, 'icon_circle-empty');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (64, 'icon_check_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (63, 'icon_check');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (62, 'icon_calulator');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (61, 'icon_calculator_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (60, 'icon_building_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (59, 'icon_building');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (58, 'icon_briefcase_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (57, 'icon_briefcase');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (56, 'icon_box-selected');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (55, 'icon_box-empty');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (54, 'icon_box-checked');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (53, 'icon_balance');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (52, 'icon_adjust-vert');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (51, 'icon_adjust-horiz');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (50, 'arrow-up-down');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (49, 'arrow_up-down_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (48, 'arrow_up');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (47, 'arrow_triangle-up_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (46, 'arrow_triangle-up');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (45, 'arrow_triangle-right_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (44, 'arrow_triangle-right');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (43, 'arrow_triangle-left_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (42, 'arrow_triangle-left');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (41, 'arrow_triangle-down_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (40, 'arrow_triangle-down');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (39, 'arrow_right-up');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (38, 'arrow_right-down');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (37, 'arrow_right');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (36, 'arrow_move');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (35, 'arrow_left-up');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (34, 'arrow_left-right_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (33, 'arrow_left-right');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (32, 'arrow_left-down');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (31, 'arrow_left');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (30, 'arrow_expand_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (29, 'arrow_expand_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (28, 'arrow_expand');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (27, 'arrow_down');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (26, 'arrow_condense');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (25, 'arrow_carrot-up_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (24, 'arrow_carrot-up');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (23, 'arrow_carrot-right_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (22, 'arrow_carrot-right');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (21, 'arrow_carrot-left_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (20, 'arrow_carrot-left');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (19, 'arrow_carrot-down_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (18, 'arrow_carrot-down');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (17, 'arrow_carrot-2up_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (16, 'arrow_carrot-2up');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (15, 'arrow_carrot-2right_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (14, 'arrow_carrot-2right');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (13, 'arrow_carrot-2left_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (12, 'arrow_carrot-2left');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (11, 'arrow_carrot-2down_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (10, 'arrow_carrot-2down');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (9, 'arrow_back');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (8, 'icon_wallet_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (7, 'icon_shield_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (6, 'icon_percent_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (5, 'icon_pens_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (4, 'icon_mug_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (3, 'icon_like_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (2, 'icon_globe_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (1, 'icon_flowchart_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (0, 'icon_easel_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (359, 'social_youtube_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (358, 'social_youtube_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (357, 'social_youtube');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (356, 'social_wordpress_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (355, 'social_wordpress_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (354, 'social_wordpress');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (353, 'social_vimeo_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (352, 'social_vimeo_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (351, 'social_vimeo');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (350, 'social_twitter_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (349, 'social_twitter_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (348, 'social_twitter');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (347, 'social_tumblr_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (346, 'social_tumblr_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (345, 'social_tumblr');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (344, 'social_tumbleupon');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (343, 'social_stumbleupon_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (342, 'social_stumbleupon_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (341, 'social_spotify_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (340, 'social_spotify_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (339, 'social_spotify');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (338, 'social_skype_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (337, 'social_skype_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (336, 'social_skype');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (335, 'social_share_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (334, 'social_share_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (333, 'social_share');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (332, 'social_rss_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (331, 'social_rss_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (330, 'social_rss');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (329, 'social_pinterest_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (328, 'social_pinterest_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (327, 'social_pinterest');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (326, 'social_picassa_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (325, 'social_picassa_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (324, 'social_picassa');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (323, 'social_myspace_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (322, 'social_myspace_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (321, 'social_myspace');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (320, 'social_linkedin_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (319, 'social_linkedin_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (318, 'social_linkedin');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (317, 'social_instagram_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (316, 'social_instagram_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (315, 'social_instagram');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (314, 'social_googleplus_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (313, 'social_googleplus_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (312, 'social_googleplus');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (311, 'social_googledrive_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (310, 'social_googledrive_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (309, 'social_googledrive');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (308, 'social_flickr_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (307, 'social_flickr_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (306, 'social_flickr');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (305, 'social_facebook_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (304, 'social_facebook_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (303, 'social_facebook');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (302, 'social_dribbble_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (301, 'social_dribbble_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (300, 'social_dribbble');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (299, 'social_deviantart_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (298, 'social_deviantart_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (297, 'social_deviantart');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (296, 'social_delicious_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (295, 'social_delicious_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (294, 'social_delicious');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (293, 'social_blogger_square');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (292, 'social_blogger_circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (291, 'social_blogger');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (290, 'icon_upload');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (289, 'icon_trash');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (288, 'icon_toolbox');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (287, 'icon_tags');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (286, 'icon_tag');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (285, 'icon_ribbon');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (284, 'icon_quotations_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (283, 'icon_pushpin');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (282, 'icon_profile');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (281, 'icon_pin');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (280, 'icon_phone');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (279, 'icon_pause_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (278, 'icon_music');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (277, 'icon_mic');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (276, 'icon_map');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (275, 'icon_mail');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (274, 'icon_lock-open');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (273, 'icon_lock');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (272, 'icon_lightbulb');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (271, 'icon_key');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (270, 'icon_house');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (269, 'icon_heart');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (268, 'icon_group');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (267, 'icon_grid-3x3');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (266, 'icon_grid-2x2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (265, 'icon_gift');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (264, 'icon_drawer');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (263, 'icon_download');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (262, 'icon_cursor');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (261, 'icon_contacts');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (260, 'icon_cone');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (259, 'icon_compass');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (258, 'icon_cloud-upload');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (257, 'icon_cloud-download');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (256, 'icon_cloud');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (255, 'icon_clock');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (254, 'icon_cart');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (253, 'icon_camera');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (252, 'icon_book');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (251, 'icon_bag');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (250, 'icon_archive');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (249, 'icon_zoom-out');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (248, 'icon_zoom-in');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (247, 'icon_volume-low_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (246, 'icon_volume-low');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (245, 'icon_volume-high_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (244, 'icon_volume-high');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (243, 'icon_vol-mute_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (242, 'icon_vol-mute');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (241, 'icon_trash_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (240, 'icon_tools');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (239, 'icon_toolbox_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (238, 'icon_tool');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (237, 'icon_tags_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (236, 'icon_tag_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (235, 'icon_tablet');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (234, 'icon_table');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (233, 'icon_stop_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (232, 'icon_star-half_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (231, 'icon_star-half');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (230, 'icon_star_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (229, 'icon_star');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (228, 'icon_ribbon_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (227, 'icon_refresh');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (226, 'icon_quotations_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (225, 'icon_quotations');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (224, 'icon_question_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (223, 'icon_question_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (222, 'icon_question');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (221, 'icon_pushpin_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (220, 'icon_plus_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (219, 'icon_pin_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (218, 'icon_piechart');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (217, 'icon_pencil_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (216, 'icon_paperclip');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (215, 'icon_mobile');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (214, 'icon_minus_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (213, 'icon_mic_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (212, 'icon_menu-square_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (211, 'icon_menu-circle_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (210, 'icon_map_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (209, 'icon_mail_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (208, 'icon_lock-open_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (207, 'icon_lock_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (206, 'icon_loading');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (205, 'icon_link_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (204, 'icon_link');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (203, 'icon_lightbulb_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (202, 'icon_lifesaver');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (201, 'icon_laptop');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (200, 'icon_key_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (199, 'icon_info');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (198, 'icon_images');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (197, 'icon_image');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (196, 'icon_house_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (195, 'icon_heart_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (194, 'icon_headphones');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (193, 'icon_gift_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (192, 'icon_genius');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (191, 'icon_folder-open');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (190, 'icon_folder-add');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (189, 'icon_folder_upload');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (188, 'icon_folder_download');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (187, 'icon_folder');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (186, 'icon_film');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (185, 'icon_error-triangle_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (184, 'icon_error-triangle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (183, 'icon_error-oct');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (182, 'icon_error-circle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (181, 'icon_drawer_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (180, 'icon_documents');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (179, 'icon_document');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (178, 'icon_desktop');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (177, 'icon_cursor_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (176, 'icon_creditcard');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (175, 'icon_contacts_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (174, 'icon_cone_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (173, 'icon_compass_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (172, 'icon_comment_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (171, 'icon_comment');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (170, 'icon_cogs');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (169, 'icon_cog');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (168, 'icon_cloud-upload_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (167, 'icon_cloud-download_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (166, 'icon_cloud_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (165, 'icon_close_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (164, 'icon_clock_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (163, 'icon_check_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (162, 'icon_chat_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (161, 'icon_chat');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (160, 'icon_cart_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (159, 'icon_camera_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (158, 'icon_calendar');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (157, 'icon_book_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (156, 'icon_blocked');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (155, 'icon_bag_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (154, 'icon_archive_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (153, 'arrow_up_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (152, 'arrow_triangle-up_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (151, 'arrow_triangle-right_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (150, 'arrow_triangle-left_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (149, 'arrow_triangle-down_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (148, 'arrow_right-up_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (147, 'arrow_right-down_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (146, 'arrow_right_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (145, 'arrow_left-up_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (144, 'arrow_left-down_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (143, 'arrow_left_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (142, 'arrow_expand_alt3');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (141, 'arrow_down_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (140, 'arrow_condense_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (139, 'arrow_carrot-right_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (138, 'arrow_carrot-left_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (137, 'arrow_carrot-down_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (136, 'arrow_carrot-2up_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (135, 'arrow_carrot-2right_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (134, 'arrow_carrot-2left_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (133, 'arrow_carrot-2dwnn_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (132, 'arrow_carrot_up_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (131, 'icon_zoom-out_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (130, 'icon_zoom-in_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (129, 'icon_wallet');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (128, 'icon_ul');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (127, 'icon_target');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (126, 'icon_stop_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (125, 'icon_stop');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (124, 'icon_shield');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (123, 'icon_search2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (122, 'icon_search_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (121, 'icon_search');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (120, 'icon_rook');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (119, 'icon_puzzle_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (118, 'icon_puzzle');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (117, 'icon_printer-alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (116, 'icon_printer');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (115, 'icon_plus-box');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (114, 'icon_plus_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (113, 'icon_plus');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (112, 'icon_percent');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (111, 'icon_pens');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (110, 'icon_pencil-edit_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (109, 'icon_pencil-edit');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (108, 'icon_pencil');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (107, 'icon_pause_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (106, 'icon_pause');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (105, 'icon_ol');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (104, 'icon_mug');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (103, 'icon_minus-box');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (102, 'icon_minus-06');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (101, 'icon_minus_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (100, 'icon_menu-square_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (99, 'icon_menu-circle_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (98, 'icon_menu');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (97, 'icon_like');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (96, 'icon_info_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (95, 'icon_id-2_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (94, 'icon_id-2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (93, 'icon_id_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (92, 'icon_id');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (91, 'icon_hourglass');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (90, 'icon_globe-2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (89, 'icon_globe');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (88, 'icon_folder-open_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (87, 'icon_folder-alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (86, 'icon_folder-add_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (85, 'icon_flowchart');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (84, 'icon_floppy_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (83, 'icon_floppy');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (82, 'icon_error-oct_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (81, 'icon_error-circle_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (80, 'icon_easel');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (79, 'icon_drive_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (78, 'icon_drive');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (77, 'icon_documents_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (76, 'icon_document_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (75, 'icon_dislike_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (74, 'icon_dislike');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (73, 'icon_datareport_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (72, 'icon_datareport');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (71, 'icon_currency_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (70, 'icon_currency');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (69, 'icon_close_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (68, 'icon_close');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (67, 'icon_clipboard');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (66, 'icon_circle-slelected');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (65, 'icon_circle-empty');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (64, 'icon_check_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (63, 'icon_check');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (62, 'icon_calulator');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (61, 'icon_calculator_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (60, 'icon_building_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (59, 'icon_building');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (58, 'icon_briefcase_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (57, 'icon_briefcase');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (56, 'icon_box-selected');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (55, 'icon_box-empty');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (54, 'icon_box-checked');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (53, 'icon_balance');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (52, 'icon_adjust-vert');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (51, 'icon_adjust-horiz');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (50, 'arrow-up-down');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (49, 'arrow_up-down_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (48, 'arrow_up');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (47, 'arrow_triangle-up_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (46, 'arrow_triangle-up');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (45, 'arrow_triangle-right_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (44, 'arrow_triangle-right');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (43, 'arrow_triangle-left_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (42, 'arrow_triangle-left');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (41, 'arrow_triangle-down_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (40, 'arrow_triangle-down');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (39, 'arrow_right-up');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (38, 'arrow_right-down');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (37, 'arrow_right');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (36, 'arrow_move');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (35, 'arrow_left-up');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (34, 'arrow_left-right_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (33, 'arrow_left-right');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (32, 'arrow_left-down');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (31, 'arrow_left');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (30, 'arrow_expand_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (29, 'arrow_expand_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (28, 'arrow_expand');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (27, 'arrow_down');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (26, 'arrow_condense');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (25, 'arrow_carrot-up_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (24, 'arrow_carrot-up');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (23, 'arrow_carrot-right_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (22, 'arrow_carrot-right');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (21, 'arrow_carrot-left_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (20, 'arrow_carrot-left');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (19, 'arrow_carrot-down_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (18, 'arrow_carrot-down');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (17, 'arrow_carrot-2up_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (16, 'arrow_carrot-2up');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (15, 'arrow_carrot-2right_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (14, 'arrow_carrot-2right');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (13, 'arrow_carrot-2left_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (12, 'arrow_carrot-2left');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (11, 'arrow_carrot-2down_alt2');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (10, 'arrow_carrot-2down');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (9, 'arrow_back');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (8, 'icon_wallet_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (7, 'icon_shield_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (6, 'icon_percent_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (5, 'icon_pens_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (4, 'icon_mug_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (3, 'icon_like_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (2, 'icon_globe_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (1, 'icon_flowchart_alt');
INSERT INTO `icon` (`id`, `icons_icon_tags`) VALUES (0, 'icon_easel_alt');


#
# TABLE STRUCTURE FOR: logo
#

DROP TABLE IF EXISTS `logo`;

CREATE TABLE `logo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `logo` varchar(500) DEFAULT NULL,
  `thumb` varchar(500) DEFAULT NULL,
  `title` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `logo` (`id`, `logo`, `thumb`, `title`) VALUES (1, 'LOGO.png', 'LOGO.png', 'Logo Eri Grafika');


#
# TABLE STRUCTURE FOR: pengunjung
#

DROP TABLE IF EXISTS `pengunjung`;

CREATE TABLE `pengunjung` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(50) NOT NULL DEFAULT '0',
  `tanggal` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1053 DEFAULT CHARSET=latin1;

INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1, '::1', '2019-04-27');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (2, '192.168.1.3', '2019-04-27');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (3, '::1', '2019-04-28');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (4, '192.168.1.3', '2019-04-28');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (5, '656464', '2018-04-28');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (6, '544456', '2019-05-27');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (7, '8989484', '2019-06-28');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (8, '087454', '2019-06-28');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (9, '192.168.1.3', '2019-04-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (10, '::1', '2019-05-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (11, '::1', '2019-05-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (12, '::1', '2019-05-13');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (13, '::1', '2019-05-16');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (14, '::1', '2019-05-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (15, '192.168.1.14', '2019-05-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (16, '::1', '2019-05-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (17, '192.168.1.14', '2019-05-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (18, '192.168.1.14', '2019-05-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (19, '::1', '2019-05-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (20, '::1', '2019-05-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (21, '::1', '2019-05-23');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (22, '::1', '2019-05-24');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (23, '::1', '2019-05-25');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (24, '36.65.156.45', '2019-05-25');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (25, '64.233.172.170', '2019-05-25');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (26, '66.249.83.64', '2019-05-25');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (27, '36.65.194.146', '2019-05-25');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (28, '64.233.173.170', '2019-05-25');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (29, '107.170.231.78', '2019-05-25');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (30, '69.171.251.32', '2019-05-25');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (31, '69.171.251.28', '2019-05-25');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (32, '69.171.251.19', '2019-05-25');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (33, '69.171.251.3', '2019-05-25');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (34, '69.171.251.40', '2019-05-25');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (35, '69.171.251.47', '2019-05-25');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (36, '69.171.251.10', '2019-05-25');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (37, '69.171.251.36', '2019-05-25');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (38, '69.171.251.29', '2019-05-25');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (39, '69.171.251.41', '2019-05-25');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (40, '103.253.214.10', '2019-05-26');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (41, '173.252.87.20', '2019-05-26');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (42, '36.82.106.163', '2019-05-26');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (43, '64.233.173.170', '2019-05-26');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (44, '64.233.173.174', '2019-05-26');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (45, '36.65.189.216', '2019-05-26');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (46, '157.55.39.109', '2019-05-26');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (47, '209.17.97.66', '2019-05-26');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (48, '209.17.97.74', '2019-05-26');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (49, '36.73.33.181', '2019-05-26');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (50, '84.236.19.208', '2019-05-26');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (51, '114.5.221.187', '2019-05-26');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (52, '36.73.34.242', '2019-05-26');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (53, '64.233.173.172', '2019-05-26');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (54, '3.89.13.27', '2019-05-26');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (55, '69.171.251.27', '2019-05-27');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (56, '69.171.251.17', '2019-05-27');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (57, '69.171.251.43', '2019-05-27');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (58, '69.171.251.2', '2019-05-27');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (59, '69.171.251.10', '2019-05-27');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (60, '69.171.251.22', '2019-05-27');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (61, '69.171.251.30', '2019-05-27');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (62, '69.171.251.48', '2019-05-27');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (63, '69.171.251.29', '2019-05-27');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (64, '192.162.102.230', '2019-05-27');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (65, '36.65.194.146', '2019-05-27');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (66, '120.188.81.207', '2019-05-27');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (67, '162.244.33.8', '2019-05-27');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (68, '137.226.113.26', '2019-05-27');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (69, '120.188.81.207', '2019-05-28');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (70, '209.17.97.82', '2019-05-28');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (71, '208.80.194.42', '2019-05-28');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (72, '3.89.13.27', '2019-05-28');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (73, '54.245.177.170', '2019-05-28');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (74, '54.203.71.34', '2019-05-28');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (75, '209.17.96.218', '2019-05-28');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (76, '66.249.65.171', '2019-05-28');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (77, '137.226.113.27', '2019-05-28');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (78, '46.4.33.48', '2019-05-28');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (79, '36.65.194.146', '2019-05-28');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (80, '182.253.62.117', '2019-05-28');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (81, '77.234.68.53', '2019-05-29');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (82, '120.188.78.109', '2019-05-29');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (83, '54.218.69.57', '2019-05-29');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (84, '120.188.81.52', '2019-05-29');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (85, '36.65.194.146', '2019-05-29');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (86, '3.89.13.27', '2019-05-29');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (87, '36.90.153.214', '2019-05-29');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (88, '209.17.97.42', '2019-05-29');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (89, '209.17.96.18', '2019-05-29');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (90, '103.253.214.20', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (91, '120.188.87.175', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (92, '23.129.64.204', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (93, '158.174.122.199', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (94, '185.10.68.247', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (95, '194.71.109.44', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (96, '176.10.104.240', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (97, '35.0.127.52', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (98, '109.69.67.17', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (99, '192.195.80.10', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (100, '51.15.59.9', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (101, '176.10.99.200', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (102, '176.31.208.193', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (103, '95.216.145.1', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (104, '51.15.125.181', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (105, '178.175.132.227', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (106, '185.56.171.94', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (107, '85.214.243.115', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (108, '66.70.228.168', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (109, '209.95.51.11', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (110, '195.228.45.176', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (111, '109.70.100.23', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (112, '54.39.148.233', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (113, '62.102.148.68', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (114, '199.249.230.123', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (115, '178.17.174.198', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (116, '23.129.64.192', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (117, '162.247.74.202', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (118, '94.102.49.152', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (119, '185.10.68.123', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (120, '77.247.181.162', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (121, '31.220.0.225', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (122, '199.249.230.69', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (123, '192.160.102.170', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (124, '137.226.113.34', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (125, '199.249.230.70', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (126, '144.217.255.89', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (127, '178.17.166.148', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (128, '23.129.64.103', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (129, '82.221.128.191', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (130, '46.166.162.53', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (131, '23.129.64.102', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (132, '87.120.36.157', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (133, '120.188.83.53', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (134, '185.158.251.201', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (135, '91.219.237.244', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (136, '185.193.125.42', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (137, '78.109.23.2', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (138, '82.221.131.5', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (139, '167.99.42.89', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (140, '109.70.100.19', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (141, '51.38.126.229', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (142, '5.150.254.67', '2019-05-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (143, '192.42.116.15', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (144, '109.70.100.18', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (145, '62.4.14.206', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (146, '212.83.146.233', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (147, '120.188.79.213', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (148, '62.4.14.198', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (149, '66.220.149.17', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (150, '66.220.149.19', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (151, '178.17.174.198', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (152, '77.247.181.165', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (153, '171.25.193.20', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (154, '66.220.149.35', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (155, '66.220.149.10', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (156, '66.220.149.16', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (157, '66.220.149.48', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (158, '66.220.149.4', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (159, '66.220.149.14', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (160, '66.220.149.39', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (161, '103.253.214.20', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (162, '178.17.170.91', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (163, '36.73.34.242', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (164, '77.234.68.53', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (165, '217.170.197.89', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (166, '66.220.149.34', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (167, '66.220.149.12', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (168, '66.220.149.28', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (169, '66.220.149.36', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (170, '66.220.149.36', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (171, '185.222.202.65', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (172, '82.221.128.191', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (173, '54.39.148.232', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (174, '199.249.230.113', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (175, '198.98.57.155', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (176, '209.17.96.42', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (177, '66.249.65.171', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (178, '182.253.62.117', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (179, '185.169.42.131', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (180, '109.70.100.23', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (181, '66.249.65.173', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (182, '144.217.164.104', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (183, '62.102.148.68', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (184, '104.244.78.233', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (185, '51.15.59.9', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (186, '36.65.217.50', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (187, '199.249.230.80', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (188, '199.249.230.82', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (189, '66.220.149.45', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (190, '66.220.149.46', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (191, '66.220.149.11', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (192, '66.220.149.23', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (193, '66.220.149.2', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (194, '66.220.149.32', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (195, '66.220.149.40', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (196, '66.220.149.5', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (197, '193.90.12.117', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (198, '62.210.201.91', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (199, '51.15.53.83', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (200, '62.210.202.81', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (201, '209.141.41.41', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (202, '158.174.122.199', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (203, '109.70.100.22', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (204, '36.73.35.174', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (205, '193.9.115.24', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (206, '195.206.105.217', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (207, '23.129.64.190', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (208, '35.162.47.148', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (209, '65.19.167.130', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (210, '192.42.116.14', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (211, '198.167.223.133', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (212, '91.221.110.5', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (213, '199.249.230.85', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (214, '192.42.116.27', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (215, '195.228.45.176', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (216, '77.247.181.162', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (217, '172.96.118.14', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (218, '199.249.230.102', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (219, '23.129.64.156', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (220, '162.244.80.228', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (221, '89.31.57.5', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (222, '23.129.64.165', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (223, '94.230.208.148', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (224, '199.249.230.109', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (225, '51.255.109.173', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (226, '51.255.109.162', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (227, '62.210.37.82', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (228, '18.85.192.253', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (229, '46.38.235.14', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (230, '199.249.230.75', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (231, '51.15.117.50', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (232, '176.31.208.193', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (233, '31.31.77.217', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (234, '176.10.99.200', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (235, '158.69.217.87', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (236, '185.220.102.6', '2019-05-31');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (237, '120.188.74.79', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (238, '193.201.225.45', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (239, '178.175.132.229', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (240, '171.25.193.20', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (241, '192.160.102.170', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (242, '185.125.33.114', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (243, '103.253.214.20', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (244, '91.227.68.74', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (245, '66.249.73.14', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (246, '199.87.154.255', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (247, '199.195.252.152', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (248, '195.176.3.20', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (249, '199.249.230.86', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (250, '82.221.128.191', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (251, '54.36.108.162', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (252, '18.18.248.17', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (253, '199.249.230.75', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (254, '109.70.100.27', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (255, '185.193.125.42', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (256, '185.220.100.252', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (257, '104.244.76.13', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (258, '212.21.66.6', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (259, '36.65.185.86', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (260, '193.90.12.119', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (261, '77.247.181.165', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (262, '193.9.114.139', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (263, '195.176.3.23', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (264, '178.17.166.148', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (265, '192.42.116.25', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (266, '66.102.6.147', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (267, '178.175.132.212', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (268, '27.122.59.100', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (269, '109.70.100.18', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (270, '104.223.70.223', '2019-06-01');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (271, '103.253.214.20', '2019-06-02');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (272, '54.39.148.234', '2019-06-02');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (273, '77.234.68.53', '2019-06-02');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (274, '172.96.118.14', '2019-06-02');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (275, '209.141.41.103', '2019-06-02');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (276, '192.42.116.20', '2019-06-02');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (277, '199.249.230.110', '2019-06-02');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (278, '182.253.62.117', '2019-06-02');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (279, '69.171.251.16', '2019-06-02');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (280, '69.171.251.45', '2019-06-02');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (281, '69.171.251.14', '2019-06-02');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (282, '69.171.251.30', '2019-06-02');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (283, '69.171.251.15', '2019-06-02');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (284, '69.171.251.35', '2019-06-02');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (285, '69.171.251.5', '2019-06-02');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (286, '69.171.251.25', '2019-06-02');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (287, '171.25.193.78', '2019-06-02');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (288, '36.65.174.73', '2019-06-02');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (289, '109.70.100.21', '2019-06-03');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (290, '163.172.151.47', '2019-06-03');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (291, '18.85.192.253', '2019-06-03');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (292, '115.178.254.77', '2019-06-03');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (293, '51.15.74.143', '2019-06-03');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (294, '192.160.102.170', '2019-06-03');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (295, '103.253.214.20', '2019-06-03');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (296, '120.188.81.29', '2019-06-03');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (297, '198.98.61.88', '2019-06-03');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (298, '31.31.77.217', '2019-06-03');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (299, '109.69.67.17', '2019-06-03');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (300, '34.220.131.44', '2019-06-03');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (301, '75.149.221.170', '2019-06-03');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (302, '31.13.115.15', '2019-06-03');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (303, '31.13.115.4', '2019-06-03');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (304, '193.9.114.139', '2019-06-03');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (305, '23.129.64.191', '2019-06-03');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (306, '80.127.116.96', '2019-06-03');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (307, '36.65.174.96', '2019-06-03');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (308, '23.129.64.153', '2019-06-03');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (309, '185.220.102.4', '2019-06-03');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (310, '199.249.230.104', '2019-06-03');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (311, '79.134.234.247', '2019-06-03');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (312, '37.128.222.30', '2019-06-03');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (313, '104.194.228.240', '2019-06-03');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (314, '167.99.42.89', '2019-06-03');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (315, '114.5.220.148', '2019-06-03');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (316, '198.98.50.112', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (317, '51.15.59.175', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (318, '158.69.192.239', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (319, '51.15.235.211', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (320, '199.195.248.177', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (321, '109.70.100.23', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (322, '158.174.122.199', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (323, '103.253.214.20', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (324, '185.195.237.118', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (325, '46.165.230.5', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (326, '199.249.230.68', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (327, '35.203.251.58', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (328, '209.85.238.76', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (329, '209.85.238.74', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (330, '192.42.116.22', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (331, '194.68.44.88', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (332, '104.244.74.165', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (333, '199.195.250.77', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (334, '66.70.228.168', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (335, '109.70.100.18', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (336, '109.70.100.26', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (337, '199.249.230.113', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (338, '208.80.194.41', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (339, '213.61.215.54', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (340, '62.102.148.68', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (341, '199.249.230.74', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (342, '185.248.160.65', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (343, '185.147.80.155', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (344, '195.176.3.24', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (345, '199.249.230.78', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (346, '144.217.255.89', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (347, '79.137.79.167', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (348, '23.129.64.171', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (349, '209.141.56.103', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (350, '182.253.62.117', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (351, '193.169.145.66', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (352, '217.182.198.204', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (353, '178.164.164.33', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (354, '66.249.71.49', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (355, '23.129.64.193', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (356, '51.68.174.112', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (357, '171.25.193.25', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (358, '178.175.143.165', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (359, '31.220.0.225', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (360, '208.12.90.101', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (361, '120.188.74.63', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (362, '62.212.95.51', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (363, '205.185.120.227', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (364, '199.249.230.118', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (365, '109.70.100.22', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (366, '64.113.32.29', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (367, '176.10.99.200', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (368, '199.249.230.110', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (369, '54.179.168.108', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (370, '95.211.186.147', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (371, '178.17.166.148', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (372, '194.71.109.44', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (373, '51.77.52.216', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (374, '185.248.160.52', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (375, '54.39.148.234', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (376, '176.10.104.240', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (377, '185.4.132.135', '2019-06-04');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (378, '23.129.64.174', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (379, '36.65.174.96', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (380, '199.249.230.89', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (381, '62.102.148.68', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (382, '109.70.100.25', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (383, '178.175.132.228', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (384, '103.253.214.20', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (385, '185.162.229.116', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (386, '162.247.74.202', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (387, '199.249.230.83', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (388, '51.68.214.45', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (389, '62.102.148.69', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (390, '178.175.143.166', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (391, '18.85.192.253', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (392, '109.70.100.20', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (393, '138.59.18.110', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (394, '144.217.165.133', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (395, '109.70.100.27', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (396, '207.244.70.35', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (397, '37.139.8.104', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (398, '192.42.116.14', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (399, '193.201.225.45', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (400, '51.15.59.9', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (401, '199.249.230.75', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (402, '91.221.110.5', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (403, '109.70.100.22', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (404, '195.176.3.24', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (405, '195.228.45.176', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (406, '185.125.33.114', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (407, '51.158.166.175', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (408, '51.15.80.14', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (409, '199.249.230.81', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (410, '144.217.165.223', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (411, '199.249.230.82', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (412, '176.126.83.211', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (413, '54.37.234.66', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (414, '23.129.64.212', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (415, '178.175.132.214', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (416, '209.17.97.58', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (417, '199.249.230.103', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (418, '185.100.86.182', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (419, '66.220.149.25', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (420, '66.220.149.23', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (421, '66.220.149.22', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (422, '66.220.149.21', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (423, '66.220.149.7', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (424, '54.36.108.162', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (425, '195.176.3.23', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (426, '82.221.128.191', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (427, '195.176.3.20', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (428, '66.220.149.27', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (429, '66.220.149.11', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (430, '66.220.149.16', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (431, '66.220.149.31', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (432, '66.220.149.12', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (433, '66.220.149.46', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (434, '66.220.149.20', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (435, '66.220.149.38', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (436, '66.220.149.42', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (437, '179.43.149.44', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (438, '209.141.58.114', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (439, '199.249.230.68', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (440, '51.77.193.218', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (441, '46.166.129.156', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (442, '107.155.49.126', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (443, '81.169.202.52', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (444, '85.248.227.163', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (445, '185.220.102.7', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (446, '144.217.166.19', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (447, '209.141.51.150', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (448, '109.70.100.26', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (449, '185.242.113.224', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (450, '50.97.77.189', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (451, '104.218.63.75', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (452, '104.244.73.219', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (453, '144.217.7.154', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (454, '178.164.164.33', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (455, '178.175.132.212', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (456, '185.220.100.253', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (457, '109.70.100.19', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (458, '199.249.230.109', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (459, '94.32.66.15', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (460, '182.16.189.18', '2019-06-05');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (461, '195.176.3.19', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (462, '23.129.64.166', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (463, '178.175.143.166', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (464, '109.201.133.100', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (465, '199.249.230.102', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (466, '192.42.116.25', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (467, '171.25.193.20', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (468, '185.220.102.4', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (469, '192.42.116.18', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (470, '109.70.100.27', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (471, '171.25.193.78', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (472, '178.175.143.157', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (473, '144.217.255.89', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (474, '178.175.132.225', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (475, '178.17.170.91', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (476, '144.217.60.211', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (477, '109.70.100.19', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (478, '199.249.230.108', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (479, '178.175.135.99', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (480, '195.228.45.176', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (481, '109.70.100.23', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (482, '195.176.3.23', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (483, '50.99.193.144', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (484, '192.42.116.16', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (485, '38.100.53.77', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (486, '213.61.215.54', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (487, '176.10.99.200', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (488, '130.149.80.199', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (489, '23.129.64.172', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (490, '109.70.100.22', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (491, '178.17.166.147', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (492, '193.9.114.139', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (493, '89.234.157.254', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (494, '62.102.148.69', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (495, '31.220.40.54', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (496, '158.174.122.199', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (497, '165.227.77.110', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (498, '159.203.94.89', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (499, '185.107.47.171', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (500, '162.247.73.192', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (501, '212.21.66.6', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (502, '199.249.230.111', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (503, '31.220.0.225', '2019-06-06');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (504, '77.247.181.163', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (505, '109.70.100.26', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (506, '103.253.214.20', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (507, '109.70.100.27', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (508, '209.141.61.45', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (509, '185.150.44.22', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (510, '35.193.107.49', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (511, '176.10.99.200', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (512, '199.249.230.104', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (513, '95.128.43.164', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (514, '158.174.122.199', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (515, '178.17.166.148', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (516, '178.175.132.210', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (517, '62.102.148.68', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (518, '209.95.51.11', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (519, '87.118.112.63', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (520, '173.252.127.14', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (521, '145.239.91.37', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (522, '69.171.251.46', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (523, '120.188.76.113', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (524, '69.171.251.15', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (525, '69.171.251.15', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (526, '69.171.251.3', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (527, '69.171.251.11', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (528, '69.171.251.4', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (529, '69.171.251.40', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (530, '69.171.251.31', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (531, '69.171.251.24', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (532, '66.249.71.49', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (533, '35.0.127.52', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (534, '163.172.12.160', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (535, '178.17.171.39', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (536, '185.195.237.25', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (537, '137.74.167.96', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (538, '195.176.3.23', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (539, '51.15.106.67', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (540, '209.17.96.202', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (541, '178.17.174.198', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (542, '51.15.49.134', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (543, '199.249.230.106', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (544, '199.249.230.103', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (545, '198.98.60.40', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (546, '5.188.62.5', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (547, '192.42.116.23', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (548, '23.129.64.194', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (549, '199.87.154.255', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (550, '23.129.64.193', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (551, '199.249.230.88', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (552, '199.249.230.87', '2019-06-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (553, '195.176.3.23', '2019-06-08');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (554, '109.70.100.20', '2019-06-08');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (555, '120.188.80.16', '2019-06-08');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (556, '195.176.3.20', '2019-06-08');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (557, '103.253.214.20', '2019-06-08');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (558, '178.175.132.212', '2019-06-08');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (559, '199.249.230.103', '2019-06-08');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (560, '192.160.102.170', '2019-06-08');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (561, '192.42.116.13', '2019-06-08');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (562, '158.174.122.199', '2019-06-08');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (563, '34.219.56.33', '2019-06-08');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (564, '66.70.228.168', '2019-06-08');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (565, '51.15.187.209', '2019-06-08');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (566, '70.42.131.189', '2019-06-08');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (567, '199.249.230.82', '2019-06-08');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (568, '51.158.117.104', '2019-06-08');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (569, '51.158.98.255', '2019-06-08');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (570, '51.15.75.133', '2019-06-08');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (571, '198.96.155.3', '2019-06-08');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (572, '64.233.172.165', '2019-06-08');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (573, '51.75.162.53', '2019-06-08');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (574, '178.164.164.33', '2019-06-08');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (575, '69.171.251.20', '2019-06-08');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (576, '69.171.251.16', '2019-06-08');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (577, '69.171.251.36', '2019-06-08');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (578, '69.171.251.43', '2019-06-08');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (579, '69.171.251.5', '2019-06-08');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (580, '69.171.251.18', '2019-06-08');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (581, '69.171.251.14', '2019-06-08');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (582, '69.171.251.9', '2019-06-08');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (583, '69.171.251.3', '2019-06-08');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (584, '69.171.251.1', '2019-06-08');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (585, '52.24.13.84', '2019-06-09');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (586, '103.253.214.20', '2019-06-09');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (587, '182.253.62.114', '2019-06-09');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (588, '209.95.51.11', '2019-06-09');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (589, '178.17.166.149', '2019-06-09');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (590, '192.42.116.14', '2019-06-09');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (591, '185.195.237.24', '2019-06-09');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (592, '69.171.251.29', '2019-06-09');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (593, '69.171.251.7', '2019-06-09');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (594, '69.171.251.41', '2019-06-09');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (595, '69.171.251.30', '2019-06-09');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (596, '69.171.251.38', '2019-06-09');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (597, '69.171.251.27', '2019-06-09');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (598, '69.171.251.12', '2019-06-09');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (599, '69.171.251.24', '2019-06-09');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (600, '69.171.251.45', '2019-06-09');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (601, '69.171.251.22', '2019-06-09');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (602, '69.171.251.40', '2019-06-09');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (603, '193.201.225.45', '2019-06-09');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (604, '51.15.117.50', '2019-06-09');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (605, '199.195.248.177', '2019-06-09');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (606, '64.233.172.190', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (607, '36.73.33.24', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (608, '103.253.214.20', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (609, '204.17.56.42', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (610, '209.95.51.11', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (611, '192.42.116.26', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (612, '185.220.100.252', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (613, '109.70.100.19', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (614, '112.215.244.165', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (615, '35.160.180.255', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (616, '195.176.3.20', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (617, '36.65.159.145', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (618, '66.249.71.23', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (619, '66.249.71.24', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (620, '54.211.54.101', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (621, '167.86.94.107', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (622, '66.249.71.45', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (623, '51.15.187.209', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (624, '185.220.102.4', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (625, '103.253.214.10', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (626, '178.128.170.60', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (627, '178.17.166.149', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (628, '178.164.146.36', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (629, '194.68.44.88', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (630, '23.129.64.152', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (631, '158.69.217.87', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (632, '178.175.132.229', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (633, '120.188.72.172', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (634, '109.70.100.21', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (635, '195.123.213.211', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (636, '62.210.10.111', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (637, '51.255.45.144', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (638, '163.172.11.200', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (639, '209.17.96.250', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (640, '209.17.96.242', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (641, '199.249.230.100', '2019-06-10');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (642, '23.129.64.210', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (643, '81.171.29.146', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (644, '120.188.72.172', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (645, '23.129.64.168', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (646, '103.253.214.20', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (647, '198.98.58.135', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (648, '109.70.100.23', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (649, '199.249.230.122', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (650, '36.73.33.24', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (651, '89.234.157.254', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (652, '78.109.23.2', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (653, '54.37.234.66', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (654, '192.42.116.26', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (655, '208.80.194.41', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (656, '137.74.169.241', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (657, '94.140.116.189', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (658, '104.244.77.199', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (659, '138.197.177.62', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (660, '185.248.160.65', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (661, '46.165.230.5', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (662, '36.65.159.145', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (663, '144.217.7.154', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (664, '198.98.56.149', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (665, '23.129.64.207', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (666, '109.70.100.26', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (667, '209.17.97.66', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (668, '109.70.100.20', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (669, '109.70.100.21', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (670, '209.17.96.42', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (671, '199.249.230.117', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (672, '91.219.238.95', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (673, '217.12.221.196', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (674, '198.50.200.129', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (675, '65.181.124.115', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (676, '195.254.134.194', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (677, '64.233.173.172', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (678, '36.65.147.179', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (679, '178.17.171.39', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (680, '64.246.161.42', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (681, '192.160.102.169', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (682, '199.249.230.105', '2019-06-11');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (683, '23.129.64.194', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (684, '87.120.254.98', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (685, '103.253.214.20', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (686, '199.249.230.103', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (687, '171.25.193.20', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (688, '185.220.102.4', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (689, '45.125.66.215', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (690, '217.182.198.204', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (691, '178.20.55.18', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (692, '144.217.60.239', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (693, '95.142.161.63', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (694, '167.99.42.89', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (695, '34.213.180.96', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (696, '217.115.10.132', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (697, '109.70.100.23', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (698, '77.247.181.163', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (699, '51.15.244.99', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (700, '89.234.157.254', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (701, '180.246.86.60', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (702, '66.70.228.168', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (703, '192.42.116.22', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (704, '178.164.146.36', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (705, '36.65.155.92', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (706, '199.249.230.101', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (707, '78.109.23.2', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (708, '158.174.122.199', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (709, '109.70.100.21', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (710, '120.188.79.59', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (711, '87.120.36.157', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (712, '199.249.230.76', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (713, '109.70.100.24', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (714, '144.217.166.26', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (715, '199.249.230.73', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (716, '23.129.64.204', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (717, '178.175.132.227', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (718, '80.67.172.162', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (719, '120.188.73.225', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (720, '198.98.57.155', '2019-06-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (721, '144.217.255.89', '2019-06-13');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (722, '109.70.100.22', '2019-06-13');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (723, '87.118.116.90', '2019-06-13');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (724, '103.253.214.20', '2019-06-13');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (725, '199.249.230.66', '2019-06-13');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (726, '209.95.51.11', '2019-06-13');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (727, '31.185.104.20', '2019-06-13');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (728, '194.71.109.44', '2019-06-13');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (729, '199.249.230.104', '2019-06-13');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (730, '109.70.100.19', '2019-06-13');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (731, '178.175.132.226', '2019-06-13');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (732, '185.195.237.117', '2019-06-13');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (733, '104.236.239.165', '2019-06-13');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (734, '51.38.69.114', '2019-06-13');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (735, '109.70.100.21', '2019-06-13');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (736, '193.9.115.24', '2019-06-13');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (737, '78.109.23.2', '2019-06-13');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (738, '79.137.79.167', '2019-06-13');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (739, '199.249.230.65', '2019-06-13');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (740, '77.247.181.163', '2019-06-13');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (741, '138.246.253.5', '2019-06-13');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (742, '36.65.155.92', '2019-06-13');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (743, '66.249.71.47', '2019-06-13');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (744, '51.158.109.172', '2019-06-13');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (745, '157.55.39.38', '2019-06-13');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (746, '103.253.214.20', '2019-06-14');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (747, '66.249.65.173', '2019-06-14');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (748, '3.214.21.251', '2019-06-14');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (749, '157.55.39.195', '2019-06-14');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (750, '109.70.100.20', '2019-06-14');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (751, '109.70.100.21', '2019-06-14');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (752, '185.125.33.114', '2019-06-14');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (753, '71.19.148.20', '2019-06-14');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (754, '23.129.64.171', '2019-06-14');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (755, '36.65.155.92', '2019-06-14');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (756, '209.17.96.10', '2019-06-14');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (757, '69.171.251.3', '2019-06-14');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (758, '69.171.251.46', '2019-06-14');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (759, '69.171.251.37', '2019-06-14');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (760, '69.171.251.15', '2019-06-14');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (761, '69.171.251.41', '2019-06-14');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (762, '69.171.251.10', '2019-06-14');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (763, '69.171.251.20', '2019-06-14');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (764, '69.171.251.45', '2019-06-14');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (765, '69.171.251.42', '2019-06-14');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (766, '69.171.251.24', '2019-06-14');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (767, '69.171.251.4', '2019-06-14');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (768, '51.158.120.6', '2019-06-15');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (769, '103.253.214.10', '2019-06-15');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (770, '103.253.214.20', '2019-06-15');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (771, '163.172.76.63', '2019-06-15');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (772, '36.73.33.21', '2019-06-15');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (773, '35.182.226.3', '2019-06-15');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (774, '36.72.217.125', '2019-06-15');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (775, '54.165.90.203', '2019-06-15');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (776, '157.55.39.88', '2019-06-15');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (777, '103.253.214.20', '2019-06-16');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (778, '3.214.21.251', '2019-06-16');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (779, '66.249.73.16', '2019-06-16');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (780, '217.115.10.132', '2019-06-16');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (781, '109.70.100.26', '2019-06-16');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (782, '104.244.74.78', '2019-06-16');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (783, '209.95.51.11', '2019-06-16');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (784, '199.249.230.118', '2019-06-16');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (785, '199.249.230.115', '2019-06-16');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (786, '87.118.110.27', '2019-06-16');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (787, '185.169.42.131', '2019-06-16');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (788, '23.129.64.155', '2019-06-16');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (789, '199.249.230.108', '2019-06-16');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (790, '199.249.230.111', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (791, '109.70.100.20', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (792, '23.129.64.152', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (793, '171.25.193.25', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (794, '103.253.214.20', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (795, '109.70.100.22', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (796, '176.10.104.240', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (797, '204.8.156.142', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (798, '164.132.202.92', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (799, '182.253.62.114', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (800, '217.182.198.204', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (801, '109.70.100.24', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (802, '199.249.230.79', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (803, '84.19.190.178', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (804, '89.236.112.99', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (805, '23.129.64.200', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (806, '109.70.100.18', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (807, '51.158.98.255', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (808, '178.175.148.227', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (809, '109.70.100.19', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (810, '69.171.251.13', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (811, '69.171.251.7', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (812, '69.171.251.29', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (813, '69.171.251.3', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (814, '69.171.251.41', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (815, '69.171.251.30', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (816, '69.171.251.31', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (817, '69.171.251.36', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (818, '69.171.251.9', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (819, '69.171.251.17', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (820, '36.73.33.21', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (821, '195.206.105.217', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (822, '178.17.170.194', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (823, '199.249.230.77', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (824, '158.69.37.14', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (825, '46.101.9.216', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (826, '217.170.197.83', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (827, '178.175.132.209', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (828, '109.70.100.27', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (829, '69.171.251.8', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (830, '69.171.251.27', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (831, '69.171.251.20', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (832, '69.171.251.32', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (833, '23.129.64.188', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (834, '69.171.251.34', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (835, '69.171.251.24', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (836, '69.171.251.43', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (837, '69.171.251.25', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (838, '199.249.230.105', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (839, '36.84.0.98', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (840, '173.252.127.9', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (841, '109.70.100.25', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (842, '185.165.168.229', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (843, '193.9.114.139', '2019-06-17');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (844, '109.70.100.24', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (845, '185.107.70.202', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (846, '103.208.220.122', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (847, '103.253.214.20', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (848, '178.175.143.163', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (849, '199.249.230.107', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (850, '167.86.94.107', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (851, '109.70.100.22', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (852, '159.89.125.103', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (853, '23.129.64.210', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (854, '178.17.166.150', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (855, '157.157.87.22', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (856, '195.176.3.19', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (857, '23.129.64.165', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (858, '74.82.47.194', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (859, '178.175.132.213', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (860, '51.15.59.9', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (861, '192.160.102.166', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (862, '36.65.179.195', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (863, '178.17.170.194', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (864, '176.10.107.180', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (865, '34.212.68.145', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (866, '185.195.237.25', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (867, '185.112.254.195', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (868, '185.100.87.207', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (869, '164.132.51.91', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (870, '77.247.181.162', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (871, '185.65.135.180', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (872, '199.249.230.121', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (873, '109.70.100.20', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (874, '85.248.227.165', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (875, '208.80.194.41', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (876, '176.10.99.200', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (877, '178.175.132.226', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (878, '3.214.21.251', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (879, '199.249.230.73', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (880, '192.42.116.13', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (881, '51.15.235.211', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (882, '178.17.166.147', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (883, '69.171.251.10', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (884, '69.171.251.11', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (885, '69.171.251.6', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (886, '69.171.251.27', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (887, '69.171.251.13', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (888, '171.25.193.78', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (889, '69.171.251.34', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (890, '69.171.251.5', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (891, '69.171.251.25', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (892, '69.171.251.31', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (893, '69.171.251.28', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (894, '69.171.251.12', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (895, '69.171.251.17', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (896, '69.171.251.29', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (897, '191.101.85.99', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (898, '178.164.146.203', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (899, '209.141.58.114', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (900, '199.249.230.113', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (901, '94.230.208.148', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (902, '173.255.192.219', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (903, '178.175.132.211', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (904, '46.165.230.5', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (905, '145.239.91.37', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (906, '23.129.64.189', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (907, '192.42.116.26', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (908, '23.129.64.180', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (909, '217.12.223.56', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (910, '192.42.116.25', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (911, '51.75.162.53', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (912, '23.129.64.214', '2019-06-18');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (913, '178.17.166.150', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (914, '144.217.165.223', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (915, '204.85.191.8', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (916, '23.129.64.187', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (917, '103.253.214.20', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (918, '199.249.230.74', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (919, '199.249.230.89', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (920, '199.249.230.104', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (921, '54.39.148.232', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (922, '51.38.126.229', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (923, '192.160.102.168', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (924, '199.249.230.121', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (925, '23.129.64.208', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (926, '23.129.64.202', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (927, '94.102.51.78', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (928, '82.221.128.191', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (929, '109.70.100.21', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (930, '94.230.208.147', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (931, '104.244.77.49', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (932, '3.214.21.251', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (933, '173.244.209.5', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (934, '212.21.66.6', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (935, '195.206.105.217', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (936, '217.115.10.132', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (937, '178.175.135.102', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (938, '87.118.112.63', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (939, '77.247.181.165', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (940, '199.249.230.105', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (941, '199.249.230.103', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (942, '199.249.230.114', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (943, '35.0.127.52', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (944, '144.217.80.80', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (945, '185.242.113.224', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (946, '182.253.62.114', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (947, '185.220.100.253', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (948, '23.129.64.213', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (949, '176.53.90.26', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (950, '209.17.96.210', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (951, '23.129.64.190', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (952, '199.195.250.77', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (953, '66.249.65.171', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (954, '31.220.40.54', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (955, '36.73.149.102', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (956, '185.220.100.252', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (957, '36.73.33.21', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (958, '34.221.13.148', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (959, '45.125.65.45', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (960, '66.249.73.14', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (961, '23.129.64.172', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (962, '89.31.57.5', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (963, '51.15.59.9', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (964, '23.129.64.186', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (965, '109.70.100.26', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (966, '195.176.3.19', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (967, '178.17.166.148', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (968, '167.114.145.234', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (969, '178.17.166.146', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (970, '162.247.74.200', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (971, '198.96.155.3', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (972, '144.217.166.59', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (973, '87.118.116.90', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (974, '54.39.148.234', '2019-06-19');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (975, '51.75.162.53', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (976, '185.220.102.7', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (977, '51.77.52.216', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (978, '178.17.170.194', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (979, '23.129.64.185', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (980, '104.244.73.126', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (981, '199.249.230.117', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (982, '185.220.102.4', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (983, '103.253.214.20', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (984, '36.65.161.151', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (985, '185.220.102.6', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (986, '212.21.66.6', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (987, '158.69.217.87', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (988, '23.129.64.171', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (989, '109.70.100.18', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (990, '31.220.40.54', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (991, '199.249.230.101', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (992, '199.249.230.105', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (993, '87.118.122.51', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (994, '46.182.106.190', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (995, '104.192.0.58', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (996, '198.98.59.161', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (997, '51.255.45.144', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (998, '23.129.64.169', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (999, '188.214.104.146', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1000, '38.39.192.78', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1001, '54.191.137.174', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1002, '199.249.230.104', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1003, '89.108.99.6', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1004, '173.252.95.32', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1005, '173.252.95.16', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1006, '173.252.95.30', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1007, '173.252.95.44', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1008, '173.252.95.47', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1009, '173.252.95.17', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1010, '173.252.95.36', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1011, '185.220.102.8', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1012, '173.252.95.27', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1013, '173.252.95.29', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1014, '173.252.95.23', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1015, '173.252.95.26', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1016, '173.252.95.35', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1017, '46.38.235.14', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1018, '51.77.62.52', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1019, '199.249.230.102', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1020, '199.249.230.100', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1021, '104.244.76.13', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1022, '138.246.253.5', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1023, '46.165.245.154', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1024, '199.249.230.112', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1025, '91.221.110.5', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1026, '195.176.3.20', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1027, '167.86.94.107', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1028, '198.50.200.129', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1029, '185.42.170.203', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1030, '69.171.251.27', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1031, '192.42.116.16', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1032, '173.252.95.20', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1033, '173.252.95.19', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1034, '173.252.95.7', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1035, '173.252.95.39', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1036, '173.252.95.37', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1037, '173.252.95.12', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1038, '5.252.176.20', '2019-06-20');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1039, '::1', '2019-06-25');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1040, '::1', '2019-06-26');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1041, '::1', '2019-06-28');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1042, '192.168.1.15', '2019-06-28');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1043, '::1', '2019-07-02');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1044, '::1', '2019-07-03');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1045, '::1', '2019-07-07');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1046, '::1', '2019-07-12');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1047, '::1', '2019-07-13');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1048, '192.168.1.75', '2019-07-13');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1049, '::1', '2019-07-26');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1050, '127.0.0.1', '2019-07-30');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1051, '::1', '2019-08-16');
INSERT INTO `pengunjung` (`id`, `ip_address`, `tanggal`) VALUES (1052, '::1', '2019-08-20');


#
# TABLE STRUCTURE FOR: penilaian
#

DROP TABLE IF EXISTS `penilaian`;

CREATE TABLE `penilaian` (
  `id` int(11) NOT NULL,
  `nama` varchar(500) NOT NULL,
  `perusahaan` varchar(500) NOT NULL,
  `gambar` varchar(500) NOT NULL DEFAULT 'default.png',
  `keterangan` varchar(500) NOT NULL,
  `stars` int(11) NOT NULL,
  `ip_address` varchar(50) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: popup
#

DROP TABLE IF EXISTS `popup`;

CREATE TABLE `popup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `judul` varchar(100) NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `keterangan` varchar(500) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `popup` (`id`, `judul`, `gambar`, `keterangan`, `status`) VALUES (1, 'test', 'gambar', 'fwmnj gfmjwkncvfrwevke', 1);
INSERT INTO `popup` (`id`, `judul`, `gambar`, `keterangan`, `status`) VALUES (2, 'dq', 'dq.jpg', 'dqdqd', 0);


#
# TABLE STRUCTURE FOR: portofolio
#

DROP TABLE IF EXISTS `portofolio`;

CREATE TABLE `portofolio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `judul` varchar(500) NOT NULL DEFAULT '0',
  `gambar` varchar(500) NOT NULL DEFAULT '0',
  `thumb` varchar(500) NOT NULL DEFAULT '0',
  `isi` varchar(500) NOT NULL DEFAULT '0',
  `tanggal` varchar(500) NOT NULL DEFAULT '0',
  `id_admin` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: portofolio_kategori
#

DROP TABLE IF EXISTS `portofolio_kategori`;

CREATE TABLE `portofolio_kategori` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `portofolio_kategori` (`id`, `nama`) VALUES (5, 'Hotel');
INSERT INTO `portofolio_kategori` (`id`, `nama`) VALUES (15, 'Instansi');
INSERT INTO `portofolio_kategori` (`id`, `nama`) VALUES (4, 'jalan');
INSERT INTO `portofolio_kategori` (`id`, `nama`) VALUES (2, 'Partai');
INSERT INTO `portofolio_kategori` (`id`, `nama`) VALUES (1, 'Restauran');
INSERT INTO `portofolio_kategori` (`id`, `nama`) VALUES (14, 'Sekolah');
INSERT INTO `portofolio_kategori` (`id`, `nama`) VALUES (6, 'Swalayan');
INSERT INTO `portofolio_kategori` (`id`, `nama`) VALUES (3, 'Warung makan');
INSERT INTO `portofolio_kategori` (`id`, `nama`) VALUES (16, 'Wisata');


#
# TABLE STRUCTURE FOR: post
#

DROP TABLE IF EXISTS `post`;

CREATE TABLE `post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `meta` varchar(500) NOT NULL,
  `id_admin` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `judul` varchar(500) DEFAULT NULL,
  `isi` varchar(500) DEFAULT NULL,
  `gambar` varchar(500) DEFAULT NULL,
  `thumb` varchar(500) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `url` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: review
#

DROP TABLE IF EXISTS `review`;

CREATE TABLE `review` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL DEFAULT '0',
  `organisasi` varchar(100) NOT NULL DEFAULT '0',
  `review` varchar(500) NOT NULL DEFAULT '0',
  `foto` varchar(500) NOT NULL DEFAULT '0',
  `thumb` varchar(500) NOT NULL DEFAULT '0',
  `star` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sosmed
#

DROP TABLE IF EXISTS `sosmed`;

CREATE TABLE `sosmed` (
  `id` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `logo` varchar(50) NOT NULL,
  `class` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `sosmed` (`id`, `nama`, `logo`, `class`) VALUES (1, 'facebook', 'facebook.png', 'fa fa-facebook');
INSERT INTO `sosmed` (`id`, `nama`, `logo`, `class`) VALUES (2, 'twitter', '', 'fa fa-twitter');
INSERT INTO `sosmed` (`id`, `nama`, `logo`, `class`) VALUES (3, 'pinterest', '', 'fa fa-pinterest');
INSERT INTO `sosmed` (`id`, `nama`, `logo`, `class`) VALUES (4, 'instagram', '', 'fa fa-instagram');
INSERT INTO `sosmed` (`id`, `nama`, `logo`, `class`) VALUES (5, 'youtube', '', 'fa fa-youtube-play');
INSERT INTO `sosmed` (`id`, `nama`, `logo`, `class`) VALUES (5, 'whatsapp', '', 'fa fa-whatsapp');


#
# TABLE STRUCTURE FOR: team
#

DROP TABLE IF EXISTS `team`;

CREATE TABLE `team` (
  `id` int(11) NOT NULL,
  `id_posisi` int(11) NOT NULL,
  `nama` varchar(500) NOT NULL,
  `keterangan` varchar(500) NOT NULL,
  `foto` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: team_sosmed
#

DROP TABLE IF EXISTS `team_sosmed`;

CREATE TABLE `team_sosmed` (
  `id` int(11) NOT NULL,
  `id_admin` int(11) DEFAULT NULL,
  `id_sosmed` int(11) DEFAULT NULL,
  `link` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: video_depan
#

DROP TABLE IF EXISTS `video_depan`;

CREATE TABLE `video_depan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `judul` varchar(500) NOT NULL DEFAULT '0',
  `foto` varchar(500) NOT NULL DEFAULT '0',
  `link_video` varchar(500) NOT NULL DEFAULT '0',
  `keterangan` varchar(5000) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: web_info
#

DROP TABLE IF EXISTS `web_info`;

CREATE TABLE `web_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_web` varchar(500) NOT NULL DEFAULT '0',
  `alamat` varchar(500) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `web_info` (`id`, `nama_web`, `alamat`) VALUES (1, 'Erigrafika', 'Purwodadi');


#
# TABLE STRUCTURE FOR: web_keunggulan
#

DROP TABLE IF EXISTS `web_keunggulan`;

CREATE TABLE `web_keunggulan` (
  `id` int(11) NOT NULL,
  `gambar` varchar(500) NOT NULL,
  `nama` varchar(500) NOT NULL,
  `url` varchar(500) NOT NULL,
  `keterangan` varchar(500) NOT NULL,
  `tanggal` date NOT NULL,
  `id_admin` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `web_keunggulan` (`id`, `gambar`, `nama`, `url`, `keterangan`, `tanggal`, `id_admin`) VALUES (2, 'Quality.png', 'Quality', 'Quality', 'Menggunakan alat dan bahan berkualitas tinggi', '2019-06-10', 2);
INSERT INTO `web_keunggulan` (`id`, `gambar`, `nama`, `url`, `keterangan`, `tanggal`, `id_admin`) VALUES (3, 'Efficiency.png', 'Efficiency', 'Efficiency', 'Kami menggunakan offset printing untuk meningkatkan efisiensi', '2019-06-10', 2);
INSERT INTO `web_keunggulan` (`id`, `gambar`, `nama`, `url`, `keterangan`, `tanggal`, `id_admin`) VALUES (4, 'Reliability.png', 'Reliability', 'Reliability', 'Produk kami dengan kualitas yang bagus dapat bertahan dengan linkungan dan awet.', '2019-06-10', 2);
INSERT INTO `web_keunggulan` (`id`, `gambar`, `nama`, `url`, `keterangan`, `tanggal`, `id_admin`) VALUES (5, 'TIme.png', 'TIme', 'TIme', 'Layanan kami cepat dengan kualitas terjaga', '2019-06-10', 2);


#
# TABLE STRUCTURE FOR: web_layanan
#

DROP TABLE IF EXISTS `web_layanan`;

CREATE TABLE `web_layanan` (
  `id` int(11) NOT NULL,
  `gambar` varchar(5000) NOT NULL,
  `nama` varchar(5000) NOT NULL,
  `url` varchar(5000) NOT NULL,
  `keterangan` varchar(5000) DEFAULT NULL,
  `tanggal` date NOT NULL,
  `id_admin` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `web_layanan` (`id`, `gambar`, `nama`, `url`, `keterangan`, `tanggal`, `id_admin`) VALUES (2, 'banner.png', 'banner', 'banner', 'melayani pembuatan banner dan spanduk', '2019-05-30', 2);
INSERT INTO `web_layanan` (`id`, `gambar`, `nama`, `url`, `keterangan`, `tanggal`, `id_admin`) VALUES (3, 'Jersey.png', 'Jersey', 'Jersey', 'Kami melayani pembuatan jersey. Kamu bebas pilih desain yang mau dibikin, baik  Jersey Model Printing yang sekarang lagi ngetrend sampai model  biasa.', '2019-06-10', 2);
INSERT INTO `web_layanan` (`id`, `gambar`, `nama`, `url`, `keterangan`, `tanggal`, `id_admin`) VALUES (4, 'Sticker.png', 'Sticker', 'Sticker', 'Sebagai media tempel paling terkenal, stiker sudah sangat sering digunakan oleh banyak produk, musisi, politikus, hingga siapapun untuk berbagai macam keperluan. Mulai dari kepentingan promosi, koleksi, hingga dekorasi, stiker selalu menjadi andalan, khususnya promosi', '2019-06-10', 2);
INSERT INTO `web_layanan` (`id`, `gambar`, `nama`, `url`, `keterangan`, `tanggal`, `id_admin`) VALUES (5, 'Piagam.png', 'Piagam', 'Piagam', 'Cetak Sertifikat Murah untuk kebutuhan Seminar, Lomba, dan Penghargaan. dengan berbagai pilihan ', '2019-06-10', 2);
INSERT INTO `web_layanan` (`id`, `gambar`, `nama`, `url`, `keterangan`, `tanggal`, `id_admin`) VALUES (6, 'Albatros.jpg', 'Albatros', 'Albatros', 'X-BANNER / STANDING BANNER dengan bahan Albatros, tebal,bertekstur seperti kertas, berkualitas, tidak mudah sobek, tahan air, cocok untuk penempatan di dalam dan luar ruangan', '2019-06-10', 2);
INSERT INTO `web_layanan` (`id`, `gambar`, `nama`, `url`, `keterangan`, `tanggal`, `id_admin`) VALUES (7, 'Branding_Mobil.png', 'Branding Mobil', 'Branding_Mobil', 'Memberikan Gambar / Tulisan yang berisi Brand (Merk), Produk, Promosi atau Pesan yang Anda Inginkan pada Tampilan Kendaraan seperti Mobil, Pick Up, Bus, dll. Promosi yang cukup menarik dan memiliki Efek Dilihat yang cukup banyak mengingat Jalan di Kota Besar semakin Padat oleh pengguna Jalan.', '2019-06-10', 2);
INSERT INTO `web_layanan` (`id`, `gambar`, `nama`, `url`, `keterangan`, `tanggal`, `id_admin`) VALUES (8, 'Undangan.png', 'Undangan', 'Undangan', 'Kami melayani perccetakan undangan untuk acara dan event anda', '2019-06-10', 2);
INSERT INTO `web_layanan` (`id`, `gambar`, `nama`, `url`, `keterangan`, `tanggal`, `id_admin`) VALUES (9, 'Umbul-umbul.png', 'Umbul-umbul', 'Umbul-umbul', 'Melayani pembuatan umbul-umbul berbagai ukuran untuk branding perusahaan atau event anda.', '2019-06-10', 2);
INSERT INTO `web_layanan` (`id`, `gambar`, `nama`, `url`, `keterangan`, `tanggal`, `id_admin`) VALUES (10, 'Buku_Yasin.png', 'Buku Yasin', 'Buku_Yasin', 'melayani pembuatan buku yasin', '2019-06-10', 2);
INSERT INTO `web_layanan` (`id`, `gambar`, `nama`, `url`, `keterangan`, `tanggal`, `id_admin`) VALUES (11, 'Kalender.png', 'Kalender', 'Kalender', 'Mau cetak kalender dengan kualitas memikat, harga hemat? Disini tempatnya!', '2019-06-10', 2);
INSERT INTO `web_layanan` (`id`, `gambar`, `nama`, `url`, `keterangan`, `tanggal`, `id_admin`) VALUES (12, 'Kartu_Nama.png', 'Kartu Nama', 'Kartu_Nama', 'Cetak kartu nama, praktis, cepat dan murah untuk bisnis personal atau perusahaan. ', '2019-06-10', 2);


#
# TABLE STRUCTURE FOR: web_portofolio
#

DROP TABLE IF EXISTS `web_portofolio`;

CREATE TABLE `web_portofolio` (
  `id` int(11) NOT NULL,
  `nama` varchar(500) NOT NULL,
  `gambar` varchar(500) NOT NULL,
  `id_portofolio` int(11) NOT NULL,
  `url` varchar(500) NOT NULL,
  `keterangan` varchar(500) NOT NULL,
  `tanggal` date NOT NULL,
  `id_admin` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `web_portofolio` (`id`, `nama`, `gambar`, `id_portofolio`, `url`, `keterangan`, `tanggal`, `id_admin`) VALUES (5, 'Danau Resto_Banner', 'Danau_Reso_Banner.png', 1, 'Danau_Resto_Banner', 'Rumah makan atau resto terbaru di Purwodadi,  Danau Resto terletak di Jalan Gajah Mada Purwodadi. Dengan slogan \"Cerdas diRasa Asyik diSuasana\" Danau Resto Purwodadi mempersembahkan suasana alami dan juga menu yang beragam. ', '2019-06-10', 2);
INSERT INTO `web_portofolio` (`id`, `nama`, `gambar`, `id_portofolio`, `url`, `keterangan`, `tanggal`, `id_admin`) VALUES (6, 'Kyriad Hotel_Percetakan', 'Kyriad_Hotel_Percetakan.png', 5, 'Kyriad_Hotel_Percetakan', 'Hotel Bintang 3 Kyriad Grand Master Purwodadi menawarkan pengalaman bermalam yang menyenangkan.', '2019-06-10', 2);
INSERT INTO `web_portofolio` (`id`, `nama`, `gambar`, `id_portofolio`, `url`, `keterangan`, `tanggal`, `id_admin`) VALUES (7, 'Master Park Purwodadi_Percetakan', 'Master_Park_Purwodadi_Percetakan.png', 16, 'Master_Park_Purwodadi_Percetakan', 'Water park di area Master Park Purwodadi terdiri dari kolam untuk balita, kolam permainan anak, kolam arus dan kolam dewasa.', '2019-06-10', 2);
INSERT INTO `web_portofolio` (`id`, `nama`, `gambar`, `id_portofolio`, `url`, `keterangan`, `tanggal`, `id_admin`) VALUES (8, 'Danau Bernyanyi_Percetakan', 'Danau_Bernyanyi_Percetakan.png', 16, 'Danau_Bernyanyi_Percetakan', '-', '2019-06-10', 2);


#
# TABLE STRUCTURE FOR: web_slider
#

DROP TABLE IF EXISTS `web_slider`;

CREATE TABLE `web_slider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `keterangan` varchar(5000) NOT NULL,
  `tanggal` date NOT NULL,
  `id_admin` int(11) NOT NULL,
  `url` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

INSERT INTO `web_slider` (`id`, `nama`, `gambar`, `thumb`, `keterangan`, `tanggal`, `id_admin`, `url`) VALUES (8, 'Printing Outdoor', 'Printing_Outdoor.jpeg', 'Printing_Outdoor.jpeg', 'Mesin digital printing yang menghasilkan cetakan yang dapat diletakan di luar ruangan dan tahan cuaca* (Terik Matahari dan Hujan).', '2019-05-25', 2, 'Printing_Outdoor');
INSERT INTO `web_slider` (`id`, `nama`, `gambar`, `thumb`, `keterangan`, `tanggal`, `id_admin`, `url`) VALUES (9, 'Cetak Offset', 'Cetak_Offset.jpeg', 'Cetak_Offset.jpeg', ' Dengan metode offset, materi yang ingin dicetak dipindahkan dari sebuah plat ke lapisan karet, lalu ke atas permukaan bahan. Sehingga memiliki kualitas tinggi', '2019-05-25', 2, 'Cetak_Offset');
INSERT INTO `web_slider` (`id`, `nama`, `gambar`, `thumb`, `keterangan`, `tanggal`, `id_admin`, `url`) VALUES (11, 'Sublime Jersey', 'Sublime_Jersey.jpeg', 'Sublime_Jersey.jpeg', 'Kami menjual dan melayani pembuatan dan percetakan Jersey berkualiatas.', '2019-05-25', 2, 'Sublime_Jersey');
INSERT INTO `web_slider` (`id`, `nama`, `gambar`, `thumb`, `keterangan`, `tanggal`, `id_admin`, `url`) VALUES (13, 'Print A3 Plus', 'Print_A3_Plus.jpeg', 'Print_A3_Plus.jpeg', 'Tersedia A3+, Ukurannya bisa lebih dari 297 x 420 mm2', '2019-06-20', 2, 'Print_A3_Plus');


#
# TABLE STRUCTURE FOR: web_sosmed
#

DROP TABLE IF EXISTS `web_sosmed`;

CREATE TABLE `web_sosmed` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_sosmed` int(11) NOT NULL,
  `link` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: web_video
#

DROP TABLE IF EXISTS `web_video`;

CREATE TABLE `web_video` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `judul` varchar(500) NOT NULL,
  `keterangan` varchar(500) NOT NULL,
  `gambar` varchar(500) NOT NULL,
  `link_video` varchar(500) NOT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `web_video` (`id`, `judul`, `keterangan`, `gambar`, `link_video`, `status`) VALUES (1, 'Profile Erigrafika', 'Video profile kami', 'Profile_Erigrafika.PNG', 'https://www.youtube.com/watch?v=hr_7BUYkVhg', 1);


