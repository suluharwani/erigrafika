<?php
$this->load->view('admin/layout/header');
$this->load->view('admin/layout/nav');
$this->load->view('admin/layout/sidebar');
$this->load->view('admin/layout/content/content_video');
$this->load->view('admin/layout/footer');
?>