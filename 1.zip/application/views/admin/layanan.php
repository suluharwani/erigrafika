<?php
$this->load->view('admin/layout/header');
$this->load->view('admin/layout/nav');
$this->load->view('admin/layout/sidebar');
$this->load->view('admin/layout/content/content_layanan');
$this->load->view('admin/layout/footer');