<?php
$this->load->view('home/layout/header');
echo $content;
$this->load->view('home/layout/footer');
?>